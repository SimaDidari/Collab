import argparse
import os
import sys
import pathlib
import torch




def parse_args():
    p = argparse.ArgumentParser(
        description="Train neural IK networks.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )

    # task config 
    p.add_argument("--task-config", type=str)
    p.add_argument("--device", type=str)

    
    # Dataset
    p.add_argument("--n-samples", type=int, default=20000, help="Number of FK samples to generate.")
    p.add_argument("--gen-batch", type=int, default=300, help="Batch size for FK during dataset generation.")
    p.add_argument("--regenerate-data", action="store_true", help="Force regeneration of training data.")

    # IK Network
    p.add_argument("--hidden", default="512,512,256", help="Hidden layer sizes, comma-separated.")
    p.add_argument("--dropout", type=float, default=0.0)

    # Training
    p.add_argument("--epochs", type=int, default=300)
    p.add_argument("--batch-size", type=int, default=400)
    p.add_argument("--lr", type=float, default=5e-4)
    p.add_argument("--val-split", type=float, default=0.1)
    p.add_argument("--workers", type=int, default=0, help="DataLoader worker processes.")
    p.add_argument("--double", action="store_true", help="Use float64 precision (slower but more accurate for FK).")
    p.add_argument("--cpu", action="store_true", help="Force CPU even if CUDA exists.")

    # Losses
    p.add_argument("--fk-weight", type=float, default=0.5, help="Weight for FK-consistency loss term.")
    p.add_argument("--pos-weight", type=float, default=1.0, help="Relative weight of position vs. rotation in FK loss.")

    return p.parse_args()




if __name__ == "__main__":

    TASK_CONFIG_DIR = os.getenv("TASK_CONFIG_DIR")
    EMBODIMENT_DIR = os.getenv("EMBODIMENT_DIR")

    ROOT_DIR = str(pathlib.Path(__file__).parent.parent)
    sys.path.append(ROOT_DIR)
    os.chdir(ROOT_DIR)

    KADP_ROOT = str(pathlib.Path(__file__).parent.parent)

    DATA_DIR = os.path.join(KADP_ROOT, "data")
    sys.path.append(KADP_ROOT)
    sys.path.append(os.path.join(KADP_ROOT, 'KA-Diffusion-Policy'))
    sys.path.append(os.path.join(KADP_ROOT, 'KA-Diffusion-Policy', 'diffusion_policy_3d'))

    from diffusion_policy_3d.kinematics_tools.train_inv_kinematics import train
    

    args = parse_args()
    train(args, TASK_CONFIG_DIR, EMBODIMENT_DIR, DATA_DIR)
    
    
