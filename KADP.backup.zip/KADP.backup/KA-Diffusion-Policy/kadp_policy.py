if __name__ == "__main__":
    import sys
    import os
    import pathlib

    ROOT_DIR = str(pathlib.Path(__file__).parent.parent.parent)
    sys.path.append(ROOT_DIR)
    os.chdir(ROOT_DIR)

import os
import hydra
from omegaconf import OmegaConf
import pathlib
import sys
from train_kadp import TrainKADPWorkspace

KADP_ROOT = str(pathlib.Path(__file__).parent.parent)


OmegaConf.register_new_resolver("eval", eval, replace=True)


@hydra.main(
    version_base=None,
    config_path=str(pathlib.Path(__file__).parent.joinpath("diffusion_policy_3d", "config")),
)
def main(cfg):
    workspace = TrainKADPWorkspace(cfg)
    workspace.eval()


class KADP:

    def __init__(self, cfg, usr_args) -> None:
        self.policy, self.env_runner = self.get_policy_and_runner(cfg, usr_args)

    def update_obs(self, observation):
        self.env_runner.update_obs(observation)

    def get_action(self, observation=None):
        action = self.env_runner.get_action(self.policy, observation)
        return action

    def get_policy_and_runner(self, cfg, usr_args):
        TASK_CONFIG_DIR = os.getenv("TASK_CONFIG_DIR")
        EMBODIMENT_DIR = os.getenv("EMBODIMENT_DIR")

        if EMBODIMENT_DIR:
            OmegaConf.update(cfg, "embodiment_dir", EMBODIMENT_DIR)
        if TASK_CONFIG_DIR:
            OmegaConf.update(cfg, "task_config_dir", TASK_CONFIG_DIR)

        HELPER_DATA_DIR = os.path.join(KADP_ROOT, "data")
        OmegaConf.update(cfg, "helper_data_dir", HELPER_DATA_DIR)

        workspace = TrainKADPWorkspace(cfg)
        policy, env_runner = workspace.get_policy_and_runner(cfg, usr_args)
        return policy, env_runner


if __name__ == "__main__":
    main()
