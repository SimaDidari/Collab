from typing import Dict
import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from einops import rearrange, reduce
from diffusers.schedulers.scheduling_ddpm import DDPMScheduler
from termcolor import cprint
import copy
import time
import pdb

# import pytorch3d.ops as torch3d_ops

from diffusion_policy_3d.model.common.normalizer import LinearNormalizer
from diffusion_policy_3d.policy.base_policy import BasePolicy
from diffusion_policy_3d.model.diffusion.conditional_unet1d import ConditionalUnet1D
from diffusion_policy_3d.common.pytorch_util import dict_apply
from diffusion_policy_3d.common.model_util import print_params
from diffusion_policy_3d.model.vision.pointnet_extractor import DP3Encoder

from diffusion_policy_3d.kinematics_tools.helper import KinematicsHelper


class KADP(BasePolicy):

    def __init__(
        self,
        shape_meta: dict,
        noise_scheduler: DDPMScheduler,
        kinematics_helper: KinematicsHelper,
        horizon,
        n_action_steps,
        n_obs_steps,
        num_inference_steps=None,
        diffusion_step_embed_dim=256,
        down_dims=(256, 512, 1024),
        kernel_size=5,
        n_groups=8,
        condition_type="cross_attention",
        use_down_condition=True,
        use_mid_condition=True,
        use_up_condition=True,
        encoder_output_dim=256,
        crop_shape=None,
        use_pc_color=False,
        pointnet_type="pointnet",
        pointcloud_encoder_cfg=None,
        # parameters passed to step
        **kwargs,
    ):
        super().__init__()

        self.condition_type = condition_type

        node_action_dim = kinematics_helper.checkpoint["left_arm"]["input_dim"] + kinematics_helper.checkpoint["right_arm"]["input_dim"] + 2
        joint_action_dim = kinematics_helper.checkpoint["left_arm"]["n_joints"] + kinematics_helper.checkpoint["right_arm"]["n_joints"] + 2

        obs_shape_meta = shape_meta["obs"]
        obs_dict = dict_apply(obs_shape_meta, lambda x: x["shape"])

        obs_encoder = DP3Encoder(
            observation_space=obs_dict,
            img_crop_shape=crop_shape,
            out_channel=encoder_output_dim,
            pointcloud_encoder_cfg=pointcloud_encoder_cfg,
            use_pc_color=use_pc_color,
            pointnet_type=pointnet_type,
        )

        # create diffusion model
        obs_feature_dim = obs_encoder.output_shape()

        # obs_as_global_cond is always True
        input_dim = node_action_dim
        if "cross_attention" in self.condition_type:
            global_cond_dim = obs_feature_dim
        else:
            global_cond_dim = obs_feature_dim * n_obs_steps

        self.use_pc_color = use_pc_color
        self.pointnet_type = pointnet_type
        cprint(
            f"[DiffusionUnetHybridPointcloudPolicy] use_pc_color: {self.use_pc_color}",
            "yellow",
        )
        cprint(
            f"[DiffusionUnetHybridPointcloudPolicy] pointnet_type: {self.pointnet_type}",
            "yellow",
        )

        # this is a model directly in terms of the node actions (for input and output)
        model = ConditionalUnet1D(
            input_dim=input_dim,
            local_cond_dim=None,
            global_cond_dim=global_cond_dim,
            diffusion_step_embed_dim=diffusion_step_embed_dim,
            down_dims=down_dims,
            kernel_size=kernel_size,
            n_groups=n_groups,
            condition_type=condition_type,
            use_down_condition=use_down_condition,
            use_mid_condition=use_mid_condition,
            use_up_condition=use_up_condition,
        )

        self.obs_encoder = obs_encoder
        self.model = model
        self.noise_scheduler = noise_scheduler
        self.noise_scheduler_pc = copy.deepcopy(noise_scheduler)
        pred_type = self.noise_scheduler.config.prediction_type
        if pred_type != "sample":
            raise ValueError(f"Invalid prediction type: {pred_type}. It should be equal to 'sample'")
        self.kinematics_helper = kinematics_helper
        self.normalizer = LinearNormalizer()
        self.horizon = horizon
        self.obs_feature_dim = obs_feature_dim
        self.node_action_dim = node_action_dim
        self.joint_action_dim = joint_action_dim
        self.n_action_steps = n_action_steps
        self.n_obs_steps = n_obs_steps
        self.kwargs = kwargs

        if num_inference_steps is None:
            num_inference_steps = noise_scheduler.config.num_train_timesteps
        self.num_inference_steps = num_inference_steps

        print_params(self)

    # ========= inference  ============
    def conditional_sample(
        self,
        batch_size, 
        horizon, 
        sample_dtype,
        device,
        local_cond=None,
        global_cond=None,
        generator=None,
        # keyword arguments to scheduler.step
        **kwargs,
    ):
        model = self.model
        scheduler = self.noise_scheduler

        joint_trajectory = torch.randn(
            size= (batch_size, horizon, self.joint_action_dim),
            dtype= sample_dtype,
            device= device,
        )

        # set step values
        scheduler.set_timesteps(self.num_inference_steps)

        for t in scheduler.timesteps:
            # apply forward kinematics 
            
            node_trajectory = self.kinematics_helper.get_node_actions(joint_trajectory,  self.normalizer)

            node_model_output = model(
                sample= node_trajectory,
                timestep=t,
                local_cond=local_cond,
                global_cond=global_cond,
            )

            joint_model_output = self.kinematics_helper.get_joint_actions(node_model_output,  self.normalizer)

            # 3. compute previous image: x_t -> x_t-1
            joint_trajectory = scheduler.step(
                joint_model_output,
                t,
                joint_trajectory,
            ).prev_sample

        # node_trajectory = self.kinematics_helper.get_node_actions(joint_trajectory,  self.normalizer)
        return joint_trajectory



    def predict_action(self, obs_dict: Dict[str, torch.Tensor]) -> Dict[str, torch.Tensor]:
        """
        obs_dict: must include "obs" key
        result: must include "action" key
        """
        # normalize input
        nobs = self.normalizer.normalize(obs_dict)

        if not self.use_pc_color:
            nobs["point_cloud"] = nobs["point_cloud"][..., :3]

        value = next(iter(nobs.values()))
        B, To = value.shape[:2]
        T = self.horizon
        Da = self.joint_action_dim
        To = self.n_obs_steps

        # build input
        device = self.device
        dtype = self.dtype

        # condition through global feature
        this_nobs = dict_apply(nobs, lambda x: x[:, :To, ...].reshape(-1, *x.shape[2:]))
        nobs_features = self.obs_encoder(this_nobs)

        if "cross_attention" in self.condition_type:
            global_cond = nobs_features.reshape(B, self.n_obs_steps, -1)
        else:
            global_cond = nobs_features.reshape(B, -1)


        # run sampling
        nsample = self.conditional_sample(B, T, dtype, device, local_cond=None, global_cond=global_cond,**self.kwargs)

        # unnormalize prediction
        naction_pred = nsample[..., :Da]
        action_pred = self.normalizer["joint_action"].unnormalize(naction_pred)

        # get action
        start = To - 1
        end = start + self.n_action_steps
        action = action_pred[:, start:end]

        result = {
            "action": action,
            "action_pred": action_pred,
        }
        return result
        
    # ========= training  ============
    def set_normalizer(self, normalizer: LinearNormalizer):
        self.normalizer.load_state_dict(normalizer.state_dict())

    def compute_loss(self, batch):
        # normalize input

        nobs = self.normalizer.normalize(batch["obs"])

        if not self.use_pc_color:
            nobs["point_cloud"] = nobs["point_cloud"][..., :3]


        node_actions = batch["node_action"]
        node_nactions = self.normalizer["node_action"].normalize(node_actions)
        print("The wonderful sahpe of node_nactions is: ", node_nactions.shape)

        

        batch_size = node_nactions.shape[0]
        horizon = node_nactions.shape[1]


        
        # compute joint representation of the actions
        joint_nactions = self.kinematics_helper.get_joint_actions(node_nactions, self.normalizer)


        # condition through global feature
        this_nobs = dict_apply(
            nobs, lambda x: x[:, :self.n_obs_steps, ...].reshape(-1, *x.shape[2:])
        )
        nobs_features = self.obs_encoder(this_nobs)
 
        if "cross_attention" in self.condition_type:
            global_cond = nobs_features.reshape(batch_size, self.n_obs_steps, -1)
        else:
            global_cond = nobs_features.reshape(batch_size, -1)

        
        node_trajectory = node_nactions
        joint_trajectory = joint_nactions

        # Sample noise that we'll add to the images
        noise = torch.randn(joint_trajectory.shape, device=joint_trajectory.device)

        bsz = joint_trajectory.shape[0]

        # Sample a random timestep for each image
        timesteps = torch.randint(
            0,
            self.noise_scheduler.config.num_train_timesteps,
            (bsz, ),
            device= joint_trajectory.device,
        ).long()

        # Add noise to the clean images according to the noise magnitude at each timestep
        # (this is the forward diffusion process)
        noisy_joint_trajectory = self.noise_scheduler.add_noise(joint_trajectory, noise, timesteps)

        # Convert to node space
        noisy_trajectory  = self.kinematics_helper.get_node_actions(noisy_joint_trajectory, self.normalizer)

        
        # Predict the noise residual
        pred = self.model(
            sample=noisy_trajectory,
            timestep=timesteps,
            local_cond=None,
            global_cond=global_cond,
        )

        target = node_trajectory
        
        loss = F.mse_loss(pred, target, reduction="none")
        loss = reduce(loss, "b ... -> b (...)", "mean")
        loss = loss.mean()

        loss_dict = {
            "bc_loss": loss.item(),
        }

        return loss, loss_dict
