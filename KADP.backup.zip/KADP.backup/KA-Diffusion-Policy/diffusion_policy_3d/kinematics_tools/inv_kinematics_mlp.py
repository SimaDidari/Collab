import torch
import torch.nn as nn




class IKNetwork(nn.Module):
    """
    MLP that maps concatenated pose features of arm body nodes → joint angles.

    Architecture follows the "node-to-joint" design implied by KADP:
    each selected 3D node on the robot body is described by its pose (9-D),
    and all node features are concatenated as the network input.
    """

    def __init__(
        self,
        input_dim: int,
        output_dim: int,
        hidden_dims: list[int] = (512, 512, 512, 256),
        dropout: float = 0.0,
    ):
        super().__init__()
        layers = []
        in_dim = input_dim
        for h in hidden_dims:
            layers += [nn.Linear(in_dim, h), nn.LayerNorm(h), nn.ELU()]
            if dropout > 0:
                layers.append(nn.Dropout(dropout))
            in_dim = h
        layers.append(nn.Linear(in_dim, output_dim))
        self.net = nn.Sequential(*layers)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


