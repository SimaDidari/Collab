import torch
from tqdm import tqdm
import time
import yaml

from diffusion_policy_3d.kinematics_tools.utils import pose_to_feature, build_chains_dict_from_task_config
from diffusion_policy_3d.model.common.normalizer import LinearNormalizer


from diffusion_policy_3d.kinematics_tools.inv_kinematics_mlp import IKNetwork
import os
import pytorch_kinematics as pk





class SingleArmHelper:

    def __init__(self, ik_model_checkpoint, chain_info, device):
        ckpt = ik_model_checkpoint
        self.device = torch.device(device)
        self.chain_info = chain_info

        # loading and freezing model for inverse kinematics
        self.ik_model = IKNetwork(
            input_dim=ckpt["input_dim"],
            output_dim=ckpt["n_joints"],
            hidden_dims=ckpt["hidden_dims"],
            dropout=ckpt.get("dropout", 0.0),
        ).to(device=self.device)

        self.ik_model.load_state_dict(ckpt["model_state"])
        self.ik_model.eval()
        # Freezing model parameters
        for param in self.ik_model.parameters():
            param.requires_grad = False

        self.X_mean = ckpt["X_mean"].to(self.device)
        self.X_std = ckpt["X_std"].to(self.device)
        self.Y_mean = ckpt["Y_mean"].to(self.device)
        self.Y_std = ckpt["Y_std"].to(self.device)
        self.lower = ckpt["lower"].to(self.device)
        self.upper = ckpt["upper"].to(self.device)
        self.node_links = ckpt["node_links"]
        self.joint_names = ckpt["joint_names"]
        return 


    def get_node_actions(self, joint_actions: torch.Tensor):
        '''
        joint_actions := input joint angles of shape B x T x  (n_joints + 1)
        Apply Forward Kinematics to get node actions
        '''
        # serial chain is used for fk
        full_chain = self.chain_info["full_chain"]
        root_link_name = self.chain_info["root_link"]
        target_links_names = self.chain_info["target_links"]

        serial_chain = pk.SerialChain(full_chain, target_links_names[-1] , root_link_name)
        serial_chain = serial_chain.to(device = self.device)


        gripper_actions = joint_actions[:, :, -1]  # shape B x T 
        gripper_actions = torch.unsqueeze(gripper_actions, 2)

        thetas = joint_actions[:,:, :-1]
        batch_dim, horizon, _ = thetas.shape 
        thetas = thetas.reshape(-1, thetas.shape[2])
        fk_result = serial_chain.forward_kinematics(thetas, end_only=False)
        pred = []
        for i, link in enumerate(self.node_links):
            mat = fk_result[link].get_matrix()  # (B*T, 4, 4)
            pred_feat = pose_to_feature(mat)     # (B*T, 3)
            pred.append(pred_feat)
        pred = torch.concat(pred, dim = -1)  # (B*T, n_nodes * 3)
        pred = pred.reshape(batch_dim, horizon, pred.shape[1]) # (B, T, n_nodes * 3)
        # add back gripper actions 
        node_actions = torch.concat([pred, gripper_actions], dim = -1)
        return node_actions
    


    def get_joint_actions(self, node_actions: torch.Tensor) -> torch.Tensor:
        """
        Parameters
        ----------
        x : node_actions

        Returns
        -------
        joint_actions
        """
        gripper_actions = node_actions[:, :, -1]  # shape B x T 
        gripper_actions = torch.unsqueeze(gripper_actions, 2)

        x = node_actions[:,:, :-1]
        batch_dim, horizon, _ = x.shape 
        x = x.reshape(-1, x.shape[2])
        x = x.to(device=self.device, dtype=self.X_mean.dtype)
        if x.dim() == 1:
            x = x.unsqueeze(0)
        x_norm = (x - self.X_mean) / self.X_std
        y_norm = self.ik_model(x_norm)
        angles = y_norm * self.Y_std + self.Y_mean
        angles = angles.clamp(self.lower, self.upper) # (B*T, n_angles)
        angles = angles.reshape(batch_dim, horizon, angles.shape[1]) # (B, T, n_angles)
        # add back gripper actions 
        joint_actions = torch.concat([angles, gripper_actions], dim = -1)
        return joint_actions
    





class KinematicsHelper:

    def __init__(self, task_config_name, task_config_dir, embodiment_dir, data_dir, device):
        chains_dict = build_chains_dict_from_task_config(task_config_name, task_config_dir, embodiment_dir)
        checkpoint_path = f"{task_config_name}_ik_model_checkpoint.pt"
        checkpoint_path = os.path.join(data_dir, checkpoint_path)
        self.checkpoint = torch.load(checkpoint_path, map_location= device)

        self.left_arm_helper = SingleArmHelper(self.checkpoint["left_arm"], chains_dict["left_arm"], device)
        self.right_arm_helper = SingleArmHelper(self.checkpoint["right_arm"], chains_dict["right_arm"], device)
        return
    
    def get_node_actions(self, x: torch.Tensor, normalizer: LinearNormalizer = None):
        joint_actions = x
        if normalizer:
            # assuming input angles are normalized, we need to unnormalize them
            joint_actions = normalizer["joint_action"].unnormalize(joint_actions)
        n_left = self.checkpoint["left_arm"]["n_joints"] + 1
        y_left  = self.left_arm_helper.get_node_actions(joint_actions[:, :,  :n_left])
        y_right = self.right_arm_helper.get_node_actions(joint_actions[:, :, n_left:])
        node_actions = torch.concat([y_left, y_right], dim = -1)
        if normalizer:
            node_actions = normalizer["node_action"].normalize(node_actions)
        return node_actions
    
    def get_joint_actions(self, x: torch.Tensor, normalizer: LinearNormalizer = None):
        node_actions = x 
        if normalizer:
            # assuming node actions are normalized, we need to unnormalize them
            node_actions = normalizer["node_action"].unnormalize(node_actions)
        n_left = self.checkpoint["left_arm"]["input_dim"] + 1
        y_left  = self.left_arm_helper.get_joint_actions(x[:, :,  :n_left])
        y_right = self.right_arm_helper.get_joint_actions(x[:, :, n_left:])
        joint_actions = torch.concat([y_left, y_right], dim = -1)
        if normalizer:
            joint_actions = normalizer["joint_action"].normalize(joint_actions)
        return joint_actions