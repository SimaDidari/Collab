import torch
import torch.nn as nn
import yaml
import os 
import pytorch_kinematics as pk
import math
from tqdm import tqdm


# ---------------------------------------------------------------------------
# Rotation utilities
# ---------------------------------------------------------------------------

def matrix_to_6d(rot: torch.Tensor) -> torch.Tensor:
    """Convert (*, 3, 3) rotation matrices to 6-D continuous rotation 
    Reference: `On the continuity of rotation representations in neural networs'(Zhou et al.)."""
    # Take first two columns: (*, 3, 2) → flatten last two dims → (*, 6)
    return rot[..., :2].reshape(*rot.shape[:-2], 6)


def sixd_to_matrix(sixd: torch.Tensor) -> torch.Tensor:
    """Recover (*, 3, 3) rotation matrix from 6-D representation."""
    a1 = sixd[..., :3]
    a2 = sixd[..., 3:]
    b1 = nn.functional.normalize(a1, dim=-1)
    b2 = nn.functional.normalize(a2 - (b1 * a2).sum(-1, keepdim=True) * b1, dim=-1)
    b3 = torch.cross(b1, b2, dim=-1)
    return torch.stack([b1, b2, b3], dim=-1)  # (*, 3, 3)


def full_pose_to_feature(transform_matrix: torch.Tensor) -> torch.Tensor:
    """
    Convert homogeneous transform (*, 4, 4) → feature vector (*, 9).
    Feature = [position (3) | 6D rotation (6)].
    """
    pos = transform_matrix[..., :3, 3]          # (*, 3)
    rot6d = matrix_to_6d(transform_matrix[..., :3, :3])  # (*, 6)
    return torch.cat([pos, rot6d], dim=-1)       # (*, 9)

def pose_to_feature(transform_matrix: torch.Tensor) -> torch.Tensor:
    """
    Convert homogeneous transform (*, 4, 4) → feature vector (*, 3).
    Feature = [position (3) | 6D rotation (6)].
    """
    pos = transform_matrix[..., :3, 3]          # (*, 3)
    return pos



# ---------------------------------------------------------------------------
# Pytorch kinematics serial chains generation
# --------------------------------------------------------------------------- 
def build_chains_dict(embodiment_list, embodiment_dir):

    chains_dict = {}

    if len(embodiment_list) == 1:
        robot_directory = os.path.join(embodiment_dir, embodiment_list[0])

        robot_config_path = os.path.join(robot_directory, "config.yml")
        with open(robot_config_path, "r", encoding="utf-8") as f:
            robot_config = yaml.load(f.read(), Loader=yaml.FullLoader)

        urdf_filepath = os.path.join(robot_directory, robot_config["urdf_path"])
        full_chain = pk.build_chain_from_urdf(open(urdf_filepath, mode="rb").read())
        print("The robot chain: ")
        full_chain.print_tree()
        print("******************************************")
        print("******************************************")
        # Left arm 
        left_root_link_name = robot_config["root_link_name"][0]
        left_target_links_name = robot_config["arm_links_name"][0]
        left_root_coords = robot_config.get("robot_pose", [[0, -0.65, 0, 1, 0, 0, 1]])[0]
        chains_dict["left_arm"] = {
            "full_chain" : full_chain,
            "target_links" : left_target_links_name,
            "root_link" : left_root_link_name,
            "root_coords": left_root_coords,
        }
        # Right arm  
        right_root_link_name = robot_config["root_link_name"][0]
        right_target_links_name = robot_config["arm_links_name"][1]
        right_root_coords = robot_config.get("robot_pose", [[0, -0.65, 0, 1, 0, 0, 1]])[0]
        chains_dict["right_arm"] = {
            "full_chain" : full_chain,
            "target_links" : right_target_links_name,
            "root_link" : right_root_link_name,
            "root_coords": right_root_coords,
        }
        chains_dict["dual"] = True
    elif len(embodiment_list) == 3:
        # TO FINISH
        stuff = 6
    else:
        raise "number of embodiment config parameters should be 1 or 3"
    return chains_dict


def get_joint_limits(serial_chain) -> tuple[torch.Tensor, torch.Tensor]:
    """
    Extract per-joint lower and upper limits from the serial_chain.
    Falls back to (-π, π) if a joint has no limits specified.
    """
    lowers, uppers = [], []
    for joint in serial_chain.get_joints():
        limit = getattr(joint, "limit", None)
        if limit is not None and limit.lower is not None and limit.upper is not None:
            lowers.append(float(limit.lower))
            uppers.append(float(limit.upper))
        else:
            lowers.append(-math.pi)
            uppers.append(math.pi)
    return (
        torch.tensor(lowers, dtype=torch.float64),
        torch.tensor(uppers, dtype=torch.float64),
    )


def build_chains_dict_from_task_config(task_config_name, task_config_dir, embodiment_dir):
    task_config_path = f"{task_config_name}.yml"
    task_config_path = os.path.join(task_config_dir, task_config_path)
    with open(task_config_path, "r", encoding="utf-8") as f:
        task_config = yaml.load(f.read(), Loader=yaml.FullLoader)

    embodiment_list = task_config["embodiment"]
    chains_dict = build_chains_dict(embodiment_list, embodiment_dir)
    return chains_dict



# ---------------------------------------------------------------------------
# Dataset generation
# --------------------------------------------------------------------------- 

def sample_configurations(
    n: int,
    lower: torch.Tensor,
    upper: torch.Tensor,
    device: torch.device,
    dtype: torch.dtype,
) -> torch.Tensor:
    """Uniform random joint angle sampling in [lower, upper]."""
    lower = lower.to(device=device, dtype=dtype)
    upper = upper.to(device=device, dtype=dtype)
    u = torch.rand(n, len(lower), device=device, dtype=dtype)
    return lower + u * (upper - lower)


def generate_dataset(
    serial_chain,
    node_links: list[str],
    n_samples: int,
    batch_size: int,
    lower: torch.Tensor,
    upper: torch.Tensor,
    device: torch.device,
    dtype: torch.dtype,
) -> tuple[torch.Tensor, torch.Tensor]:
    """
    Generate (X, Y) pairs:
      Y = joint angles                    shape (N, n_joints)
      X = concatenated 3-D pose features  shape (N, n_nodes * 3)

    FK is run in batches to avoid OOM on large N.
    """
    n_joints = len(serial_chain.get_joint_parameter_names())
    n_nodes = len(node_links)
    feat_dim = n_nodes * 3

    all_X = torch.empty(n_samples, feat_dim, dtype=dtype)
    all_Y = torch.empty(n_samples, n_joints, dtype=dtype)

    n_batches = math.ceil(n_samples / batch_size)
    collected = 0

    print(f"\n[Dataset] Generating {n_samples:,} samples "
          f"({n_joints} joints, {n_nodes} node links) …")

    for _ in tqdm(range(n_batches), desc="FK batches"):
        remaining = n_samples - collected
        b = min(batch_size, remaining)

        th = sample_configurations(b, lower, upper, device, dtype)  # (b, n_joints)

        # FK for every link in the serial_chain (end_only=False returns dict)
        fk_result = serial_chain.forward_kinematics(th, end_only=False)

        # Collect pose features for selected nodes
        node_feats = []
        for link in node_links:
            tg = fk_result[link]             # Transform3d
            mat = tg.get_matrix()            # (b, 4, 4)
            feat = pose_to_feature(mat)      # (b, 3)
            node_feats.append(feat)
        X_batch = torch.cat(node_feats, dim=-1)  # (b, n_nodes*3)

        all_X[collected: collected + b] = X_batch
        all_Y[collected: collected + b] = th
        collected += b

    print(f"[Dataset] Done. X: {all_X.shape}, Y: {all_Y.shape}")
    return all_X, all_Y

