import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset, random_split
from tqdm import tqdm
import time
import os

import pytorch_kinematics as pk

from diffusion_policy_3d.kinematics_tools.utils import pose_to_feature, get_joint_limits, generate_dataset, build_chains_dict_from_task_config


from diffusion_policy_3d.kinematics_tools.inv_kinematics_mlp import IKNetwork
from pathlib import Path


# ---------------------------------------------------------------------------
# FK-consistency loss
# ---------------------------------------------------------------------------
class FKConsistencyLoss(nn.Module):
    """
    After predicting joint angles, re-run FK and compare resulting node
    positions against the ground-truth positions embedded in the input
    feature vector. This enforces physical feasibility.
    """

    def __init__(self, serial_chain, node_links: list[str], pos_weight: float = 1.0):
        super().__init__()
        self.serial_chain = serial_chain
        self.node_links = node_links
        self.pos_weight = pos_weight

    def forward(
        self,
        pred_angles: torch.Tensor,
        target_x: torch.Tensor,
    ) -> torch.Tensor:
        """
        pred_angles: (B, n_joints)
        target_x:    (B, n_nodes * 3) ground-truth node pose features
        """
        device = pred_angles.device
        dtype = pred_angles.dtype

        serial_chain = self.serial_chain.to(device=device, dtype=dtype)
        fk_result = serial_chain.forward_kinematics(pred_angles, end_only=False)

        total_pos_loss = torch.zeros(1, device=device, dtype=dtype)

        for i, link in enumerate(self.node_links):
            mat = fk_result[link].get_matrix()  # (B, 4, 4)
            pred_feat = pose_to_feature(mat)     # (B, 3)
            tgt_feat = target_x[:, i * 3:(i + 1) * 3]  # (B, 3)

            total_pos_loss += nn.functional.smooth_l1_loss(
                pred_feat[:, :3], tgt_feat[:, :3]
            )

        n = len(self.node_links)
        return self.pos_weight * total_pos_loss / n 


def train_arm_inv_kinematics(chain_info, dtype, cache_path, args):
    device = args.device
    full_chain = chain_info["full_chain"]
    root_link_name = chain_info["root_link"]
    target_links_names = chain_info["target_links"]
    serial_chain = pk.SerialChain(full_chain, target_links_names[-1] , root_link_name)
    serial_chain = serial_chain.to(dtype = dtype, device = device)
    joint_names = serial_chain.get_joint_parameter_names()
    n_joints = len(joint_names)
    all_links_names = serial_chain.get_link_names()

    print(f"Joints ({n_joints}): {joint_names}")
    print(f"All links: {all_links_names}")

    # Resolve target nodes: each target node must correspond to a link of the serial chain
    missing = [l for l in target_links_names if l not in all_links_names]
    if missing:
        raise ValueError(f"Links not found in chain: {missing}\n"
                            f"Available: {all_links_names}")

    lower, upper = get_joint_limits(serial_chain)

    # ── Generate / load dataset ────────────────────────────────────────────
    cache_path = Path(cache_path)
    if cache_path.exists() and not(args.regenerate_data):
        print(f"[Dataset] Loading cached dataset from {cache_path}")
        data = torch.load(cache_path)
        X, Y = data["X"], data["Y"]
    else:
        X, Y = generate_dataset(
            serial_chain, target_links_names,
            n_samples=args.n_samples,
            batch_size=args.gen_batch,
            lower=lower, upper=upper,
            device=device, dtype=dtype,
        )
        torch.save({"X": X, "Y": Y}, cache_path)
        print(f"[Dataset] Saved to {cache_path}")

    # ── Normalisation ──────────────────────────────────────────────────────
    X_mean = X.mean(0)
    X_std = X.std(0).clamp(min=1e-6)
    Y_mean = Y.mean(0)
    Y_std = Y.std(0).clamp(min=1e-6)

    # ── Split ──────────────────────────────────────────────────────────────
    # dataset = TensorDataset(X_norm, Y_norm, X)  # keep raw X for FK loss
    dataset = TensorDataset(X, Y)
    n_val = max(1, int(len(dataset) * args.val_split))
    n_train = len(dataset) - n_val
    train_ds, val_ds = random_split(dataset, [n_train, n_val])

    train_loader = DataLoader(
        train_ds, batch_size=args.batch_size, shuffle=True,
        num_workers=args.workers, pin_memory=True)
    
    val_loader = DataLoader(
        val_ds, batch_size=args.batch_size * 2, shuffle=False,
        num_workers=args.workers, pin_memory=True)
    
    print(f"[Split ] Train: {n_train:,} | Val: {n_val:,}")

    # ── Model ──────────────────────────────────────────────────────────────
    input_dim = X.shape[1]
    hidden_dims = [int(h) for h in args.hidden.split(",")]
    model = IKNetwork(
        input_dim=input_dim,
        output_dim=n_joints,
        hidden_dims=hidden_dims,
        dropout=args.dropout,
    ).to(device=device, dtype=dtype)

    total_params = sum(p.numel() for p in model.parameters())
    print(f"[Model ] Parameters: {total_params:,}")

    # ── Losses ─────────────────────────────────────────────────────────────
    mse_loss = nn.SmoothL1Loss()
    fk_loss_fn = FKConsistencyLoss(serial_chain, target_links_names, pos_weight=args.pos_weight)

    # ── Optimiser ──────────────────────────────────────────────────────────
    optimizer = optim.AdamW(model.parameters(), lr=args.lr, weight_decay=1e-4)
    scheduler = optim.lr_scheduler.CosineAnnealingLR(
        optimizer, T_max=args.epochs, eta_min=args.lr * 1e-2
    )

    # Normalisation tensors on device
    X_mean_d = X_mean.to(device)
    X_std_d = X_std.to(device)
    Y_mean_d = Y_mean.to(device)
    Y_std_d = Y_std.to(device)
    lower_d = lower.to(device=device, dtype=dtype)
    upper_d = upper.to(device=device, dtype=dtype)

    best_val = float("inf")

    print(f"\n{'─'*60}")
    print(f"{'Epoch':>6} {'Train Loss':>12} {'Val Loss':>10} "
          f"{'FK Loss':>10} {'LR':>10} {'Time':>8}")
    print(f"{'─'*60}")

    for epoch in range(1, args.epochs + 1):
        t0 = time.time()
        model.train()
        train_total = 0.0

        for batch in train_loader:
            x, y = batch
            x = x.to(device)
            y = y.to(device)
            x_n = (x - X_mean_d)/X_std_d
            y_n = (y - Y_mean_d) / Y_std_d

            pred_y_n = model(x_n)

            # Regression loss in normalised space
            loss_reg = mse_loss(pred_y_n, y_n)

            # FK consistency loss in original space (de-normalise angles first)
            pred_angles = pred_y_n * Y_std_d + Y_mean_d
            # Clamp to joint limits for numerical stability
            pred_angles = pred_angles.clamp(lower_d, upper_d)
           
            loss_fk = fk_loss_fn(pred_angles, x)

            loss = loss_reg + args.fk_weight * loss_fk

            optimizer.zero_grad()
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()

            train_total += loss_reg.item()

        scheduler.step()

        # ── Validation ────────────────────────────────────────────────────
        model.eval()
        val_reg_total = 0.0
        val_fk_total = 0.0

        with torch.no_grad():
            for x, y in val_loader:
                x = x.to(device)
                y = y.to(device)
                x_n = (x - X_mean_d)/X_std_d
                y_n = (y - Y_mean_d) / Y_std_d

                pred_y_n = model(x_n)
                val_reg_total += mse_loss(pred_y_n, y_n).item()

                pred_angles = (pred_y_n * Y_std_d + Y_mean_d).clamp(lower_d, upper_d)
                val_fk_total += fk_loss_fn(pred_angles, x).item()

        n_train_batches = len(train_loader)
        n_val_batches = len(val_loader)
        avg_train = train_total / n_train_batches
        avg_val_reg = val_reg_total / n_val_batches
        avg_val_fk = val_fk_total / n_val_batches
        lr_now = scheduler.get_last_lr()[0]
        elapsed = time.time() - t0

        print(f"{epoch:6d} {avg_train:12.6f} {avg_val_reg:10.6f} "
              f"{avg_val_fk:10.6f} {lr_now:10.2e} {elapsed:7.1f}s")

        # ── Checkpoint ────────────────────────────────────────────────────
        if avg_val_reg < best_val:
            best_val = avg_val_reg
            checkpoint = {
                "epoch": epoch,
                "model_state": model.state_dict(),
                "optimizer_state": optimizer.state_dict(),
                "X_mean": X_mean,
                "X_std": X_std,
                "Y_mean": Y_mean,
                "Y_std": Y_std,
                "lower": lower,
                "upper": upper,
                "node_links": target_links_names,
                "joint_names": joint_names,
                "input_dim": input_dim,
                "hidden_dims": hidden_dims,
                "dropout": args.dropout,
                "n_joints": n_joints,
                "val_loss": best_val,
            }

    print(f"{'─'*60}")
    print(f"[Done  ] Best val loss: {best_val:.6f}")
    return checkpoint



def train(args, task_config_dir, embodiment_dir, data_dir):
    # First build the serial chains
    task_config_name = args.task_config
    chains_dict = build_chains_dict_from_task_config(task_config_name, task_config_dir, embodiment_dir)
    # train for left arm
    cache_path = f"{task_config_name}_left_arm_ik_data.pt"
    cache_path = os.path.join(data_dir, cache_path)
    left_arm_checkpoint = train_arm_inv_kinematics(chains_dict["left_arm"], torch.float32, cache_path, args)
    # train for right arm
    cache_path = f"{task_config_name}_right_arm_ik_data.pt"
    cache_path = os.path.join(data_dir, cache_path)
    right_arm_checkpoint = train_arm_inv_kinematics(chains_dict["right_arm"], torch.float32, cache_path, args)

    checkpoint ={
        "left_arm": left_arm_checkpoint,
        "right_arm": right_arm_checkpoint,
    }
    checkpoint_path = f"{task_config_name}_ik_model_checkpoint.pt"
    checkpoint_path = os.path.join(data_dir, checkpoint_path)
    torch.save(checkpoint, checkpoint_path)
    return 