#!/bin/bash 

CONTAINER_NAME="mightyflow_robotwin2_container" 
WORKDIR="-w /data2/Sima/ManiFlow_Policy/RoboTwin/policy/KADP/"


task_name=$1

CMD="bash train_rgb.sh ${task_name}"

task_config="kadp_randomized_config"

LOG_FILE="train_kadp_${task_config}.log" 

docker exec -it ${WORKDIR} ${CONTAINER_NAME} ${CMD} > ${LOG_FILE} 2>&1