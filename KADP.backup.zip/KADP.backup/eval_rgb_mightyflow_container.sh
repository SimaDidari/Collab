#!/bin/bash 

CONTAINER_NAME="mightyflow_robotwin2_container" 
WORKDIR="-w /data2/Sima/ManiFlow_Policy/RoboTwin/policy/KADP/"


task_name=$1
task_config="kadp_randomized_config"
ckpt_setting=${task_config}
expert_data_num=50
seed=23 
gpu_id=1


CMD="bash eval.sh ${task_name} ${task_config} ${ckpt_setting} ${expert_data_num} ${seed} ${gpu_id}"


LOG_FILE="eval_kadp_${task_config}.log" 

# nohup docker exec -it ${WORKDIR} ${CONTAINER_NAME} ${CMD} > ${LOG_FILE} 2>&1 &
docker exec -it ${WORKDIR} ${CONTAINER_NAME} ${CMD} > ${LOG_FILE} 2>&1 

# WANDB="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" 