#!/bin/bash 

CONTAINER_NAME="mightyflow_robotwin2_container" 
WORKDIR="-w /data2/Sima/ManiFlow_Policy/RoboTwin/policy/KADP/"

task_name=$1

CMD="bash process_data.sh  ${task_name} kadp_randomized_config 50"

task_config="kadp_randomized_config"

LOG_FILE="process_data_${task_name}_${task_config}.log" 

docker exec -it ${WORKDIR} ${CONTAINER_NAME} ${CMD} > ${LOG_FILE} 2>&1
