#!/bin/bash 

CONTAINER_NAME="mightyflow_robotwin2_container" 
WORKDIR="-w /data2/Sima/ManiFlow_Policy/RoboTwin/policy/KADP/"


CMD="bash scripts/train_kinematics_helper.sh kadp_randomized_config  cuda:1"

task_config="kadp_randomized_config"

LOG_FILE="kinematics_helper_${task_config}.log" 

docker exec -it ${WORKDIR} ${CONTAINER_NAME} ${CMD} > ${LOG_FILE} 2>&1