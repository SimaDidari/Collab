#!/bin/bash 

config_name=${1}
device=${2}


export TASK_CONFIG_DIR=/data2/Sima/ManiFlow_Policy/RoboTwin/task_config
export EMBODIMENT_DIR=/data2/Sima/ManiFlow_Policy/RoboTwin/assets/embodiments


cd KA-Diffusion-Policy


python train_kinematics_helper.py  --task-config=${config_name} --device=${device} --regenerate-data
                             