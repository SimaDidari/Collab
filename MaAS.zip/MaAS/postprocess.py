import re
import matplotlib.pyplot as plt
import os
import numpy as np

def extract_loss_data(file_path):
    """Extract batch numbers, loss values, and repetition numbers from the log file."""
    repetitions_data = {}  # Will store {repetition_num: {'batches': [], 'losses': []}}
    current_repetition = 1
    
    try:
        with open(file_path, 'r') as file:
            for line in file:
                # Check for repetition start
                rep_match = re.search(r'Starting training repetition (\d+)/\d+', line)
                if rep_match:
                    current_repetition = int(rep_match.group(1))
                    if current_repetition not in repetitions_data:
                        repetitions_data[current_repetition] = {'batches': [], 'losses': []}
                
                # Look for lines containing "Repetition X: Batch Y Loss: Z"
                batch_match = re.search(r'Repetition (\d+): Batch (\d+) Loss: ([-?\d.]+)', line)
                if batch_match:
                    rep_num = int(batch_match.group(1))
                    batch_num = int(batch_match.group(2))
                    loss_value = float(batch_match.group(3))
                    
                    if rep_num not in repetitions_data:
                        repetitions_data[rep_num] = {'batches': [], 'losses': []}
                    
                    repetitions_data[rep_num]['batches'].append(batch_num)
                    repetitions_data[rep_num]['losses'].append(loss_value)
    except FileNotFoundError:
        print(f"Warning: File {file_path} not found. Skipping...")
        return {}
    
    return repetitions_data

def plot_multiple_losses(file_paths, legends, output_dir='postprocc_res'):
    """Create and save the loss plot for multiple files with all repetitions in one plot."""
    # Create output directory if it doesn't exist
    os.makedirs(output_dir, exist_ok=True)
    
    # Define colors for different files
    colors = ['b', 'r', 'g', 'orange', 'purple', 'brown', 'pink', 'gray', 'olive', 'cyan']
    markers = ['o', 's', '^', 'D', 'v', '<', '>', 'p', '*', 'h']
    
    all_repetitions_data = {}
    all_data_found = False
    
    # Extract data from all files
    for i, (file_path, legend_name) in enumerate(zip(file_paths, legends)):
        repetitions_data = extract_loss_data(file_path)
        
        if repetitions_data:
            all_repetitions_data[legend_name] = {
                'data': repetitions_data,
                'color': colors[i % len(colors)],
                'marker': markers[i % len(markers)]
            }
            
            # Print summary for each file
            total_batches = sum(len(rep_data['batches']) for rep_data in repetitions_data.values())
            all_losses = []
            for rep_data in repetitions_data.values():
                all_losses.extend(rep_data['losses'])
            
            if all_losses:
                print(f"{legend_name}: Found {len(repetitions_data)} repetitions, "
                      f"{total_batches} total batches, "
                      f"Loss range: {min(all_losses):.3f} - {max(all_losses):.3f}")
                all_data_found = True
        else:
            print(f"No data found for {file_path}")
    
    if not all_data_found:
        print("No valid data found in any files!")
        return
    
    # Create one large plot with all repetitions
    plt.figure(figsize=(16, 10))
    
    # Find all unique repetitions across all files
    all_repetitions = set()
    for file_data in all_repetitions_data.values():
        all_repetitions.update(file_data['data'].keys())
    
    # Plot all repetitions for each file
    for legend_name, file_info in all_repetitions_data.items():
        all_batches = []
        all_losses = []
        
        # Concatenate all repetitions for this file
        for rep_num in sorted(file_info['data'].keys()):
            rep_data = file_info['data'][rep_num]
            batch_numbers = rep_data['batches']
            loss_values = rep_data['losses']
            
            if batch_numbers and loss_values:
                # Offset batch numbers to create continuous x-axis across repetitions
                max_batch = max(all_batches) if all_batches else 0
                offset_batches = [b + max_batch for b in batch_numbers]
                all_batches.extend(offset_batches)
                all_losses.extend(loss_values)
        
        if all_batches and all_losses:
            plt.plot(all_batches, all_losses, 
                    color=file_info['color'], linewidth=2, 
                    marker=file_info['marker'], markersize=3, 
                    label=legend_name, alpha=0.8)
    
    # Add vertical lines to separate repetitions
    if all_repetitions_data:
        # Calculate repetition boundaries
        sample_file_data = next(iter(all_repetitions_data.values()))['data']
        x_pos = 0
        for rep_num in sorted(sample_file_data.keys()):
            if rep_num > 1:  # Don't add line before first repetition
                plt.axvline(x=x_pos, color='gray', linestyle='--', alpha=0.5, linewidth=1)
            rep_data = sample_file_data[rep_num]
            if rep_data['batches']:
                x_pos += max(rep_data['batches'])
        
        # Add repetition labels
        x_pos = 0
        for rep_num in sorted(sample_file_data.keys()):
            rep_data = sample_file_data[rep_num]
            if rep_data['batches']:
                mid_point = x_pos + max(rep_data['batches']) / 2
                plt.text(mid_point, plt.ylim()[1] * 0.95, f'Rep {rep_num}', 
                        ha='center', va='top', fontsize=10, alpha=0.7)
                x_pos += max(rep_data['batches'])
    
    # Customize the plot
    plt.title('Training Loss per Batch - All Repetitions', fontsize=16, fontweight='bold')
    plt.xlabel('Batch Number (Continuous across repetitions)', fontsize=12)
    plt.ylabel('Loss', fontsize=12)
    plt.grid(True, alpha=0.3)
    plt.legend(fontsize=10, loc='best')
    
    # Add some styling
    plt.tight_layout()
    
    # Save the plot
    output_path = os.path.join(output_dir, 'loss_per_batch_all_repetitions.png')
    plt.savefig(output_path, dpi=300, bbox_inches='tight')
    print(f"Combined plot saved to: {output_path}")
    
    # Optionally display the plot
    plt.show()

def main():
    # Define your file paths and corresponding legends
    file_paths = [
        #'/home/davoud/MaAS/logs/sample_4_20250913.txt',  # Replace with your actual file paths
        #'/home/davoud/MaAS/logs/sample_8_20250913.txt'
       #'/home/davoud/MaAS/logs/sample_2_20250913.txt'
        '/home/davoud/MaAS/logs/sample_4_lambda_3_round4_20250916.txt',
        '/home/davoud/MaAS/logs/sample_4_lambda_3e-2_20250915.txt'
    ]
    
    legends = [
        r'$\lambda=3$, no text grad, sample 4 round 4',    # Corresponding legend names
     r'$\lambda=3$, no text grad, sample 8',
    #     r'$\lambda=3$, no text grad, sample 2',
    ]

    print(len(file_paths), len(legends))
    
    # Ensure file_paths and legends have the same length
    if len(file_paths) != len(legends):
        print("Error: Number of file paths must match number of legend names!")
        return
    
    print(f"Processing {len(file_paths)} files...")
    
    # Create and save the plot
    plot_multiple_losses(file_paths, legends)

# Alternative function for easier customization
def plot_custom_files(files_and_legends, output_dir='postprocc_res'):
    """
    Convenience function to plot with custom file-legend pairs.
    
    Args:
        files_and_legends: List of tuples [(file_path, legend_name), ...]
        output_dir: Directory to save the plot
    """
    file_paths = [item[0] for item in files_and_legends]
    legends = [item[1] for item in files_and_legends]
    plot_multiple_losses(file_paths, legends, output_dir)

if __name__ == "__main__":
    # Method 1: Using the main function
    main()
    
    # Method 2: Alternative usage (comment out main() above and uncomment below)
    # files_and_legends = [
    #     ('path/to/experiment1.txt', 'Experiment 1'),
    #     ('path/to/experiment2.txt', 'Experiment 2'),
    #     ('path/to/experiment3.txt', 'Experiment 3'),
    # ]
    # plot_custom_files(files_and_legends)