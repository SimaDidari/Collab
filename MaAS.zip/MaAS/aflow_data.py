# -*- coding: utf-8 -*-
# @Date    : 2024-10-20
# @Author  : MoshiQAQ & didi
# @Desc    : Download and extract dataset files

import os
import tarfile
import shutil
from typing import Dict

import gdown


def download_file_from_google_drive(file_id: str, filename: str) -> None:
    """Download a file from Google Drive."""
    url = f"https://drive.google.com/uc?id={file_id}"
    gdown.download(url, filename, quiet=False)


def extract_tar_gz(filename: str, extract_path: str) -> None:
    """Extract a tar.gz file to the specified path."""
    with tarfile.open(filename, "r:gz") as tar:
        tar.extractall(path=extract_path)


def process_dataset(file_id: str, filename: str, extract_path: str, force: bool = False) -> None:
    """Download, extract, and clean up a dataset if needed."""
    if os.path.exists(extract_path):
        if force:
            print(f"Force mode: Removing existing {extract_path}...")
            shutil.rmtree(extract_path)
        else:
            print(f"{extract_path} already exists. Skipping download and extraction.")
            return

    download_needed = not os.path.exists(filename)

    if download_needed:
        print(f"Downloading {filename}...")
        download_file_from_google_drive(file_id, filename)
    else:
        print(f"Using existing {filename}...")

    print(f"Extracting {filename} to {extract_path}...")
    extract_tar_gz(filename, extract_path)

    os.remove(filename)
    print(f"Removed {filename}")
    print(f"Processing {filename} completed.")


# Define the datasets to be downloaded
datasets_to_download: Dict[str, Dict[str, str]] = {
    "datasets": {
        "file_id": "1DNoegtZiUhWtvkd2xoIuElmIi4ah7k8e",
        "filename": "aflow_data.tar.gz",
        "extract_path": "data/datasets",
    },
    "results": {
        "file_id": "1Sr5wjgKf3bN8OC7G6cO3ynzJqD4w6_Dv",
        "filename": "result.tar.gz",
        "extract_path": "data/results",
    },
    "initial_rounds": {
        "file_id": "1UBoW4WBWjX2gs4I_jq3ALdXeLdwDJMdP",
        "filename": "initial_rounds.tar.gz",
        "extract_path": "workspace",
    },
}


def download(required_datasets, force_download: bool = False):
    """Main function to process all selected datasets"""
    for dataset_name in required_datasets:
        dataset = datasets_to_download[dataset_name]
        file_id = dataset["file_id"]
        filename = dataset["filename"]
        extract_path = dataset["extract_path"]

        process_needed = force_download or not os.path.exists(extract_path)
        if process_needed:
            print(f"Processing dataset: {dataset_name}")
            process_dataset(file_id, filename, extract_path, force=force_download)
        else:
            print(f"Skipping {dataset_name} as {extract_path} already exists.")


def test_download():
    """Test function to verify download and extraction process"""
    test_datasets = ["datasets", "results", "initial_rounds"]
    for name in test_datasets:
        dataset = datasets_to_download[name]
        extract_path = dataset["extract_path"]
        filename = dataset["filename"]

        # Cleanup before test
        if os.path.exists(extract_path):
            shutil.rmtree(extract_path)
        if os.path.exists(filename):
            os.remove(filename)

    # Test normal download
    download(test_datasets, force_download=False)
    for name in test_datasets:
        dataset = datasets_to_download[name]
        assert os.path.exists(dataset["extract_path"]), f"{dataset['extract_path']} not created."

    # Test skipping existing
    download(test_datasets, force_download=False)

    # Test force download
    download(test_datasets, force_download=True)
    for name in test_datasets:
        dataset = datasets_to_download[name]
        assert os.path.exists(dataset["extract_path"]), f"{dataset['extract_path']} not recreated."

    # Cleanup after test
    for name in test_datasets:
        dataset = datasets_to_download[name]
        if os.path.exists(dataset["extract_path"]):
            shutil.rmtree(dataset["extract_path"])
        if os.path.exists(dataset["filename"]):
            os.remove(dataset["filename"])

    print("All download tests passed.")


if __name__ == "__main__":
    test_download()