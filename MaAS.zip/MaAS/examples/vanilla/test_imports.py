#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Test script to verify all imports work correctly
"""

import sys
from pathlib import Path

# Add MaAS to path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

print("Testing imports...")

try:
    from maas.configs.llm_config import LLMConfig, LLMType
    print("✓ maas.configs.llm_config imported")
except ImportError as e:
    print(f"✗ Failed to import maas.configs.llm_config: {e}")

try:
    from maas.provider.llm_provider_registry import create_llm_instance
    print("✓ maas.provider.llm_provider_registry imported")
except ImportError as e:
    print(f"✗ Failed to import maas.provider.llm_provider_registry: {e}")


try:
    from maas.logs import logger
    print("✓ maas.logs imported")
except ImportError as e:
    print(f"✗ Failed to import maas.logs: {e}")

try:
    from maas.configs.models_config import ModelsConfig
    print("✓ maas.configs.models_config imported")
except ImportError as e:
    print(f"✗ Failed to import maas.configs.models_config: {e}")

print("\nTesting configuration loading...")
try:
    models_config = ModelsConfig.default()
    available_models = list(models_config.models.keys())
    print(f"✓ Configuration loaded successfully")
    print(f"  Available models: {available_models}")
except Exception as e:
    print(f"✗ Failed to load configuration: {e}")

print("\nAll imports successful!")
print("\nYou can now run:")
print("  python -m examples.vanilla.simple_example")
print("  python -m examples.vanilla.vanilla_inference --help")
