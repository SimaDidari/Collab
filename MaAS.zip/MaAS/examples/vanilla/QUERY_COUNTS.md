# HumanEval Query Counts - Quick Reference

**How many queries are in each HumanEval split?**

---

## Summary Table

| Split File | Queries | Used By | Vanilla Parameter |
|------------|---------|---------|-------------------|
| **humaneval_test.jsonl** | **131** | MaAS `--is_test True` | `--use_test_split True` (default) |
| **humaneval_validate.jsonl** | **33** | MaAS `--is_test False` | `--use_test_split False` |
| humaneval_public_test.jsonl | 159 | Not used | Not supported |

---

## For Vanilla vs MaAS Comparison

### ✅ Use This Split: TEST (131 queries)

**File**: `maas/ext/maas/data/humaneval_test.jsonl`

**MaAS Command**:
```bash
python -m examples.maas.optimize \
    --dataset HumanEval \
    --is_test True
```
→ Evaluates all **131 queries**

**Matching Vanilla Command**:
```bash
python -m examples.vanilla.vanilla_inference \
    --dataset HumanEval \
    --sample 131 \
    --use_test_split True
```
→ Evaluates all **131 queries** ✅ **SAME DATA**

---

## Detailed Information

### TEST Split (131 queries)

```
File: maas/ext/maas/data/humaneval_test.jsonl
Queries: 131
First problem: HumanEval/84 (solve)
Last problem: HumanEval/102 (choose_num)

Used by:
  • MaAS with --is_test True
  • Vanilla with --use_test_split True (default)
```

### VALIDATION Split (33 queries)

```
File: maas/ext/maas/data/humaneval_validate.jsonl
Queries: 33
First problem: HumanEval/135
Last problem: HumanEval/60

Used by:
  • MaAS training (--is_test False)
  • Vanilla with --use_test_split False
```

### PUBLIC TEST Split (159 queries)

```
File: maas/ext/maas/data/humaneval_public_test.jsonl
Queries: 159

NOT used by MaAS or Vanilla inference
```

---

## Verification Commands

### Count queries in each file:
```bash
cd /home/davoud/MaAS

# TEST split
wc -l maas/ext/maas/data/humaneval_test.jsonl
# Output: 131

# VALIDATION split
wc -l maas/ext/maas/data/humaneval_validate.jsonl
# Output: 33

# PUBLIC TEST split
wc -l maas/ext/maas/data/humaneval_public_test.jsonl
# Output: 159
```

### Check what vanilla will use:
```bash
# This will show in logs which split and how many queries
python -m examples.vanilla.vanilla_inference \
    --dataset HumanEval \
    --sample 5 \
    --use_test_split True

# Look for:
# "Data Split: TEST (same as MaAS --is_test True)"
# "Total samples in split: 131"
```

---

## Common Questions

### Q: How many queries will be evaluated?

**Answer**: Depends on your `--sample` parameter:

```bash
# Evaluate first 10 queries from TEST split (131 total)
python -m examples.vanilla.vanilla_inference \
    --dataset HumanEval \
    --sample 10 \
    --use_test_split True

# Evaluate ALL 131 queries from TEST split
python -m examples.vanilla.vanilla_inference \
    --dataset HumanEval \
    --sample 131 \
    --use_test_split True

# No --sample specified: evaluates first 10 (default)
python -m examples.vanilla.vanilla_inference \
    --dataset HumanEval \
    --use_test_split True
```

### Q: Does MaAS evaluate all 131 queries?

**Answer**: Yes! When you run:
```bash
python -m examples.maas.optimize --dataset HumanEval --is_test True
```

MaAS loads and evaluates **all 131 queries** from `humaneval_test.jsonl`.

The `--sample` parameter in MaAS controls training behavior, NOT test set size.

### Q: What if I only want to test on 50 queries?

**Answer**: For vanilla inference:
```bash
python -m examples.vanilla.vanilla_inference \
    --dataset HumanEval \
    --sample 50 \
    --use_test_split True
```

This evaluates the **first 50 queries** from the 131-query test split.

**Note**: This won't match MaAS exactly (which uses all 131), but it's useful for quick testing.

### Q: Which split should I use for comparison?

**Answer**: Use **TEST split** (131 queries) with `--use_test_split True`

This matches MaAS `--is_test True` exactly.

---

## Sample Calculation

### Evaluation Time Estimates

Assuming ~8 seconds per query on average:

| Queries | Time Estimate | Use Case |
|---------|---------------|----------|
| 5 | ~40 seconds | Quick test |
| 10 | ~1.5 minutes | Default test |
| 50 | ~7 minutes | Medium evaluation |
| 131 | **~17-20 minutes** | **Full TEST split** |

---

## Complete Examples

### Quick Test (5 queries, ~40 seconds):
```bash
python -m examples.vanilla.vanilla_inference \
    --dataset HumanEval \
    --sample 5 \
    --use_test_split True
```

### Medium Test (50 queries, ~7 minutes):
```bash
python -m examples.vanilla.vanilla_inference \
    --dataset HumanEval \
    --sample 50 \
    --use_test_split True \
    --output_file results/vanilla_humaneval_50.json
```

### Full Evaluation (131 queries, ~17-20 minutes):
```bash
python -m examples.vanilla.vanilla_inference \
    --dataset HumanEval \
    --sample 131 \
    --use_test_split True \
    --output_file results/vanilla_humaneval_full.json
```

### Full MaAS Comparison:
```bash
# Vanilla baseline (131 queries)
python -m examples.vanilla.vanilla_inference \
    --dataset HumanEval \
    --sample 131 \
    --model_name qwen3 \
    --use_test_split True \
    --output_file results/vanilla_humaneval_131.json

# MaAS optimized (131 queries)
python -m examples.maas.optimize \
    --dataset HumanEval \
    --exec_model_name "qwen3" \
    --is_test True

# Both evaluate the same 131 queries!
```

---

## JSON Output

When you run vanilla inference, the JSON output includes query counts:

```json
{
  "dataset": "HumanEval",
  "split": "TEST",
  "use_test_split": true,
  "total_in_split": 131,
  "evaluated_samples": 131,
  "correct": 85,
  "accuracy": 64.89,
  ...
}
```

**Key fields**:
- `total_in_split`: Total queries in the split (131 for TEST)
- `evaluated_samples`: How many you actually evaluated

---

## Summary

✅ **HumanEval TEST split has 131 queries**

✅ **For fair comparison with MaAS**:
```bash
# Evaluate all 131 queries
python -m examples.vanilla.vanilla_inference \
    --dataset HumanEval \
    --sample 131 \
    --use_test_split True
```

✅ **This matches your MaAS command**:
```bash
python -m examples.maas.optimize \
    --dataset HumanEval \
    --is_test True
```

Both evaluate the **same 131 queries** from `humaneval_test.jsonl`!

---

**Need more info?**
- Full comparison guide: [EXACT_MATCH_GUIDE.md](EXACT_MATCH_GUIDE.md)
- Data splits explained: [DATA_SPLITS.md](DATA_SPLITS.md)
- Complete docs: [README.md](README.md)
