# Data Splits - Vanilla vs MaAS Comparison

This document explains the exact data splits used by MaAS and how to match them in vanilla inference for fair comparison.

---

## Overview

MaAS uses different data splits for training and testing:
- **Test Split**: Used when `--is_test True` (evaluation mode)
- **Validation Split**: Used when `--is_test False` (training mode)

Vanilla inference now supports the **exact same splits** to ensure fair comparison.

---

## Data Split Details

### HumanEval Dataset

| Split | File | Samples | MaAS Usage | Vanilla Usage |
|-------|------|---------|------------|---------------|
| **Test** | `humaneval_test.jsonl` | **131** | `--is_test True` | `--use_test_split True` (default) |
| **Validation** | `humaneval_validate.jsonl` | **33** | `--is_test False` | `--use_test_split False` |
| Public Test | `humaneval_public_test.jsonl` | 159 | Not used | Not used |

### GSM8K Dataset

| Split | File | Samples | MaAS Usage | Vanilla Usage |
|-------|------|---------|------------|---------------|
| **Test** | `gsm8k_test.jsonl` | TBD | `--is_test True` | `--use_test_split True` (default) |
| **Validation** | `gsm8k_validate.jsonl` | TBD | `--is_test False` | `--use_test_split False` |

### MATH Dataset

| Split | File | Samples | MaAS Usage | Vanilla Usage |
|-------|------|---------|------------|---------------|
| **Test** | `math_test.jsonl` | TBD | `--is_test True` | `--use_test_split True` (default) |
| **Validation** | `math_validate.jsonl` | TBD | `--is_test False` | `--use_test_split False` |

---

## How to Ensure Fair Comparison

### Example: HumanEval Test Split (131 samples)

**MaAS Command**:
```bash
python -m examples.maas.optimize \
    --dataset HumanEval \
    --round 1 \
    --sample 4 \
    --exec_model_name "gpt-4o-mini" \
    --is_test True
```
- Uses: `maas/ext/maas/data/humaneval_test.jsonl` (131 samples)
- Evaluates: All 131 samples

**Vanilla Inference (Matching)**:
```bash
python -m examples.vanilla.vanilla_inference \
    --dataset HumanEval \
    --sample 131 \
    --model_name qwen3 \
    --use_test_split True
```
- Uses: `maas/ext/maas/data/humaneval_test.jsonl` (131 samples)
- Evaluates: All 131 samples
- **Result**: EXACT same data as MaAS!

---

## Complete Comparison Workflows

### Workflow 1: Full HumanEval Test Set (Recommended)

```bash
cd /home/davoud/MaAS

# Step 1: Run Vanilla Baseline on TEST split
python -m examples.vanilla.vanilla_inference \
    --dataset HumanEval \
    --sample 131 \
    --model_name qwen3 \
    --use_test_split True \
    --output_file results/vanilla_humaneval_test_131.json

# Expected Output:
# ============================================================
# Vanilla Inference on HumanEval - TEST Split
# ============================================================
# Data Split: TEST (same as MaAS --is_test True)
# Total samples in split: 131
# Evaluating: 131 samples
# ...
# Accuracy: XX.XX%

# Step 2: Run MaAS on TEST split
python -m examples.maas.optimize \
    --dataset HumanEval \
    --round 1 \
    --sample 4 \
    --exec_model_name "qwen3" \
    --is_test True

# Expected Output:
# Uses humaneval_test.jsonl (131 samples)
# Accuracy: YY.YY%

# Step 3: Compare Results
echo "Vanilla Accuracy:"
cat results/vanilla_humaneval_test_131.json | grep accuracy

echo "MaAS Accuracy:"
# Check MaAS output logs
```

---

### Workflow 2: Small Sample Test (Quick Verification)

```bash
cd /home/davoud/MaAS

# Run both on first 10 samples of TEST split
# Vanilla:
python -m examples.vanilla.vanilla_inference \
    --dataset HumanEval \
    --sample 10 \
    --use_test_split True

# MaAS (note: MaAS always uses full split, so this isn't a perfect match)
python -m examples.maas.optimize \
    --dataset HumanEval \
    --sample 4 \
    --is_test True
```

**Note**: MaAS's `--sample` parameter controls training behavior, not test set size. For exact comparison, use full test split.

---

### Workflow 3: Validation Split Comparison

```bash
cd /home/davoud/MaAS

# Run Vanilla on VALIDATION split (33 samples for HumanEval)
python -m examples.vanilla.vanilla_inference \
    --dataset HumanEval \
    --sample 33 \
    --use_test_split False \
    --output_file results/vanilla_humaneval_validation_33.json

# This matches the training data used by MaAS when --is_test False
```

---

## Verification Commands

### Check which file MaAS uses:
```bash
# Look at MaAS evaluator.py
cat maas/ext/maas/scripts/evaluator.py | grep -A 3 "_get_data_path"

# Expected output (line 60-63):
# def _get_data_path(self, dataset: DatasetType, test: bool) -> str:
#     base_path = f"maas/ext/maas/data/{dataset.lower()}"
#     return f"{base_path}_test.jsonl" if test else f"{base_path}_validate.jsonl"
```

### Check data file sizes:
```bash
cd /home/davoud/MaAS

# HumanEval
wc -l maas/ext/maas/data/humaneval_*.jsonl
#   159 humaneval_public_test.jsonl
#   131 humaneval_test.jsonl          <- MaAS --is_test True
#    33 humaneval_validate.jsonl      <- MaAS --is_test False

# GSM8K
wc -l maas/ext/maas/data/gsm8k_*.jsonl

# MATH
wc -l maas/ext/maas/data/math_*.jsonl
```

### Verify vanilla inference is using correct file:
```bash
# Run vanilla with verbose logging
python -m examples.vanilla.vanilla_inference \
    --dataset HumanEval \
    --sample 5 \
    --use_test_split True

# Check the output for:
# "Data Split: TEST (same as MaAS --is_test True)"
# "Total samples in split: 131"
```

---

## Common Mistakes to Avoid

### ❌ Mistake 1: Using Wrong Sample Count
```bash
# Wrong: Comparing 10 samples vs 131 samples
python -m examples.vanilla.vanilla_inference --dataset HumanEval --sample 10
python -m examples.maas.optimize --dataset HumanEval --is_test True  # Uses all 131

# Right: Use same number of samples
python -m examples.vanilla.vanilla_inference --dataset HumanEval --sample 131
python -m examples.maas.optimize --dataset HumanEval --is_test True
```

### ❌ Mistake 2: Using Wrong Split
```bash
# Wrong: Comparing validation split vs test split
python -m examples.vanilla.vanilla_inference --dataset HumanEval --use_test_split False
python -m examples.maas.optimize --dataset HumanEval --is_test True

# Right: Use same split
python -m examples.vanilla.vanilla_inference --dataset HumanEval --use_test_split True
python -m examples.maas.optimize --dataset HumanEval --is_test True
```

### ❌ Mistake 3: Assuming Public Test = Test
```bash
# Wrong file!
# humaneval_public_test.jsonl (159 samples) ≠ humaneval_test.jsonl (131 samples)

# MaAS uses: humaneval_test.jsonl
# Vanilla now uses: humaneval_test.jsonl (when --use_test_split True)
```

---

## Quick Reference

### Vanilla Inference Defaults
```bash
# These two are equivalent:
python -m examples.vanilla.vanilla_inference --dataset HumanEval
python -m examples.vanilla.vanilla_inference --dataset HumanEval --use_test_split True

# Both use TEST split (same as MaAS --is_test True)
```

### Exact MaAS Match
```bash
# To match MaAS exactly:
# 1. Use --use_test_split True (default)
# 2. Use full split size (131 for HumanEval test)
# 3. Same model

python -m examples.vanilla.vanilla_inference \
    --dataset HumanEval \
    --sample 131 \
    --model_name qwen3 \
    --use_test_split True \
    --output_file results/vanilla_humaneval_full.json
```

---

## JSON Output Format

Vanilla inference JSON now includes split information:

```json
{
  "dataset": "HumanEval",
  "split": "TEST",
  "use_test_split": true,
  "total_in_split": 131,
  "evaluated_samples": 131,
  "correct": 85,
  "accuracy": 64.89,
  "use_cot": true,
  "model": "qwen3",
  "results": [...]
}
```

This makes it clear which split was used for the evaluation.

---

## Summary

✅ **Vanilla inference now uses EXACT same splits as MaAS**
- `--use_test_split True` → `humaneval_test.jsonl` (same as MaAS `--is_test True`)
- `--use_test_split False` → `humaneval_validate.jsonl` (same as MaAS `--is_test False`)

✅ **For fair comparison**:
1. Use `--use_test_split True` for both
2. Use full split size (`--sample 131` for HumanEval)
3. Use same model
4. Compare accuracy directly

✅ **Verification**:
- Check logs for "Data Split: TEST (same as MaAS --is_test True)"
- Check JSON output for split information
- Verify sample counts match

---

## Need Help?

- **See which split MaAS uses**: Check `maas/ext/maas/scripts/evaluator.py:60-63`
- **Count samples**: `wc -l maas/ext/maas/data/humaneval_*.jsonl`
- **Test vanilla**: `python -m examples.vanilla.vanilla_inference --dataset HumanEval --sample 5`
- **Full docs**: See [README.md](README.md)
