#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Simple Vanilla Inference Example

This is a minimal example showing how to use vanilla inference
with your configured LLM from config2.yaml.
"""

import asyncio
import sys
from pathlib import Path

# Add MaAS to path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from maas.configs.models_config import ModelsConfig
from maas.provider.llm_provider_registry import create_llm_instance
from maas.logs import logger


async def simple_example():
    """Simple example of vanilla inference"""

    # Load configuration from config2.yaml
    models_config = ModelsConfig.default()

    # Get LLM config - first try to use default llm, then fall back to first available model
    llm_config = models_config.get("llm_base_model")
    if llm_config is None:
        # Fall back to first available model in config
        available_models = list(models_config.models.keys())
        if available_models:
            model_name = available_models[0]
            llm_config = models_config.get(model_name)
            logger.info(f"Using first available model: {model_name}")
        else:
            raise ValueError("No models found in config2.yaml")

    logger.info(f"Loaded LLM: {llm_config.model} from {llm_config.base_url}")

    # Create LLM instance
    llm = create_llm_instance(llm_config)

    # Example 1: Simple question answering
    question1 = "What is 25 * 37?"
    logger.info(f"\nQuestion: {question1}")

    response1 = await llm.aask(question1)
    logger.info(f"Response: {response1}\n")

    # Example 2: Math word problem
    question2 = """
    A store has 120 apples. They sell 45 apples in the morning and 38 apples in the afternoon.
    How many apples are left?
    """
    logger.info(f"Question: {question2.strip()}")

    response2 = await llm.aask(question2)
    logger.info(f"Response: {response2}\n")

    # Example 3: Code generation
    question3 = "Write a Python function to calculate the factorial of a number."
    logger.info(f"Question: {question3}")

    response3 = await llm.aask(question3)
    logger.info(f"Response: {response3}\n")

    # Get cost information
    costs = llm.get_costs()
    logger.info(f"Cost Summary:")
    logger.info(f"  Prompt Tokens: {costs.total_prompt_tokens}")
    logger.info(f"  Completion Tokens: {costs.total_completion_tokens}")
    logger.info(f"  Total Cost: ${costs.total_cost:.4f}")


if __name__ == "__main__":
    asyncio.run(simple_example())
