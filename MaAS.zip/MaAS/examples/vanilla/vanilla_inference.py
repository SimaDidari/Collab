#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Vanilla Model Inference - Simple Baseline for Comparison

This standalone script provides simple, direct LLM inference without
multi-agent architecture search. Use this as a baseline to compare
against MaAS's optimized operator selection approach.

Usage:
    python -m examples.vanilla.vanilla_inference \
        --dataset HumanEval \
        --model_name "llm_base_model" \
        --sample 10 \
        --output_file results/vanilla_baseline.json
"""

import argparse
import asyncio
import json
import sys
from pathlib import Path
from typing import List, Dict, Any

# Add MaAS to path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from maas.configs.models_config import ModelsConfig
from maas.provider.llm_provider_registry import create_llm_instance
from maas.logs import logger


class VanillaInference:
    """
    Simple baseline inference without multi-agent orchestration.

    This class provides direct LLM inference for comparison against
    MaAS's architecture search approach.
    """

    def __init__(self, model_name: str = None):
        """
        Initialize with LLM configuration from config2.yaml

        Args:
            model_name: Optional model name from config. If None, uses default.
        """
        models_config = ModelsConfig.default()

        # Get LLM config
        if model_name:
            llm_config = models_config.get(model_name)
            if llm_config is None:
                raise ValueError(f"Model '{model_name}' not found in config2.yaml")
        else:
            # Try default models in order
            for default_model in ["llm_base_model", "qwen3"]:
                llm_config = models_config.get(default_model)
                if llm_config:
                    model_name = default_model
                    break

            if llm_config is None:
                # Fall back to first available
                available = list(models_config.models.keys())
                if available:
                    model_name = available[0]
                    llm_config = models_config.get(model_name)
                else:
                    raise ValueError("No models found in config2.yaml")

        self.llm = create_llm_instance(llm_config)
        self.model_name = model_name
        self.results = []
        logger.info(f"VanillaInference initialized with model: {model_name}")

    async def simple_generate(self, question: str, system_prompt: str = None) -> str:
        """
        Simple generation without multi-agent orchestration.

        Args:
            question: The input question/problem
            system_prompt: Optional system prompt

        Returns:
            Generated response string
        """
        messages = []

        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})

        messages.append({"role": "user", "content": question})

        try:
            response = await self.llm.acompletion_text(messages)
            return response
        except Exception as e:
            logger.error(f"Error in simple_generate: {e}")
            return ""

    async def simple_cot_generate(self, question: str, system_prompt: str = None) -> str:
        """
        Simple Chain-of-Thought generation.

        Args:
            question: The input question/problem
            system_prompt: Optional system prompt

        Returns:
            Generated response with reasoning
        """
        cot_instruction = "\n\nLet's think step by step:"

        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})

        messages.append({"role": "user", "content": question + cot_instruction})

        try:
            response = await self.llm.acompletion_text(messages)
            return response
        except Exception as e:
            logger.error(f"Error in simple_cot_generate: {e}")
            return ""

    async def load_dataset(self, dataset_name: str, use_test_split: bool = True) -> List[Dict]:
        """
        Load dataset from file using the EXACT same split as MaAS.

        Args:
            dataset_name: Dataset name (HumanEval, MATH, GSM8K)
            use_test_split: If True, use test split (same as --is_test True in MaAS)
                           If False, use validation split (training data)

        Returns:
            List of dataset samples
        """
        # Dataset paths - EXACT same as MaAS evaluator.py line 60-63
        data_dir = Path("maas/ext/maas/data")

        if dataset_name == "HumanEval":
            # MaAS uses: humaneval_test.jsonl (131 samples) for testing
            #            humaneval_validate.jsonl (33 samples) for training
            if use_test_split:
                data_file = data_dir / "humaneval_test.jsonl"
            else:
                data_file = data_dir / "humaneval_validate.jsonl"
        elif dataset_name == "MATH":
            # MaAS uses: math_test.jsonl for testing, math_validate.jsonl for training
            if use_test_split:
                data_file = data_dir / "math_test.jsonl"
            else:
                data_file = data_dir / "math_validate.jsonl"
        elif dataset_name == "GSM8K":
            # MaAS uses: gsm8k_test.jsonl for testing, gsm8k_validate.jsonl for training
            if use_test_split:
                data_file = data_dir / "gsm8k_test.jsonl"
            else:
                data_file = data_dir / "gsm8k_validate.jsonl"
        else:
            raise ValueError(f"Unknown dataset: {dataset_name}")

        if not data_file.exists():
            raise FileNotFoundError(
                f"Dataset file not found: {data_file}. "
                f"Please ensure benchmark data is available in {data_dir}"
            )

        # Load data
        data = []
        if data_file.suffix == ".jsonl":
            with open(data_file, 'r') as f:
                for line in f:
                    data.append(json.loads(line))
        else:
            with open(data_file, 'r') as f:
                data = json.load(f)

        return data

    async def run_on_dataset(
        self,
        dataset_name: str,
        num_samples: int = None,
        use_cot: bool = True,
        output_file: str = None,
        use_test_split: bool = True
    ) -> Dict[str, Any]:
        """
        Run vanilla inference on a benchmark dataset.

        Args:
            dataset_name: One of 'HumanEval', 'MATH', 'GSM8K'
            num_samples: Number of samples to evaluate (None = all)
            use_cot: Whether to use chain-of-thought prompting
            output_file: Path to save results
            use_test_split: If True, use test split (same as MaAS --is_test True)
                           If False, use validation split (training data)

        Returns:
            Dictionary with evaluation results
        """
        # Set system prompt based on dataset
        if dataset_name == "HumanEval":
            system_prompt = "You are an expert Python programmer. Write clean, efficient code."
        elif dataset_name == "MATH":
            system_prompt = "You are an expert mathematician. Solve the following problem."
        elif dataset_name == "GSM8K":
            system_prompt = "You are an expert at solving math word problems."
        else:
            raise ValueError(f"Unknown dataset: {dataset_name}")

        # Load dataset - EXACT same split as MaAS
        try:
            dataset = await self.load_dataset(dataset_name, use_test_split=use_test_split)
        except FileNotFoundError as e:
            logger.error(str(e))
            logger.info("Note: For full benchmark evaluation, ensure data files are available.")
            logger.info("You can still use vanilla inference with custom questions via the API.")
            return None

        # Get split info
        split_name = "TEST" if use_test_split else "VALIDATION"
        total_in_split = len(dataset)

        # Limit samples if requested
        dataset = dataset[:num_samples] if num_samples else dataset

        logger.info(f"\n{'='*60}")
        logger.info(f"Vanilla Inference on {dataset_name} - {split_name} Split")
        logger.info(f"{'='*60}")
        logger.info(f"Data Split: {split_name} (same as MaAS --is_test {use_test_split})")
        logger.info(f"Total samples in split: {total_in_split}")
        logger.info(f"Evaluating: {len(dataset)} samples")
        logger.info(f"Model: {self.model_name}")
        logger.info(f"Strategy: {'Chain-of-Thought' if use_cot else 'Direct'} generation")
        logger.info(f"{'='*60}\n")

        results = []
        correct = 0
        total = 0

        for idx, item in enumerate(dataset):
            question = item.get("question") or item.get("prompt")
            ground_truth = item.get("answer") or item.get("canonical_solution")

            # Generate response
            if use_cot:
                response = await self.simple_cot_generate(question, system_prompt)
            else:
                response = await self.simple_generate(question, system_prompt)

            # Evaluate (simplified - actual evaluation depends on benchmark)
            is_correct = self._evaluate_response(
                response, ground_truth, dataset_name
            )

            if is_correct:
                correct += 1
            total += 1

            result_item = {
                "index": idx,
                "question": question,
                "response": response,
                "ground_truth": ground_truth,
                "correct": is_correct
            }
            results.append(result_item)

            # Log progress
            if (idx + 1) % 10 == 0:
                accuracy = correct / total * 100
                logger.info(f"Progress: {idx + 1}/{len(dataset)} | Accuracy: {accuracy:.2f}%")

        # Calculate final metrics
        accuracy = correct / total * 100 if total > 0 else 0

        final_results = {
            "dataset": dataset_name,
            "split": split_name,
            "use_test_split": use_test_split,
            "total_in_split": total_in_split,
            "evaluated_samples": total,
            "correct": correct,
            "accuracy": accuracy,
            "use_cot": use_cot,
            "model": self.model_name,
            "results": results
        }

        # Save results
        if output_file:
            output_path = Path(output_file)
            output_path.parent.mkdir(parents=True, exist_ok=True)
            with open(output_path, 'w') as f:
                json.dump(final_results, f, indent=2)
            logger.info(f"Results saved to {output_file}")

        logger.info(f"\n{'='*60}")
        logger.info(f"FINAL RESULTS: {dataset_name} - {split_name} Split")
        logger.info(f"{'='*60}")
        logger.info(f"Split: {split_name} (use_test_split={use_test_split})")
        logger.info(f"Total samples in split: {total_in_split}")
        logger.info(f"Evaluated: {total} samples")
        logger.info(f"Correct: {correct}")
        logger.info(f"Accuracy: {accuracy:.2f}%")
        logger.info(f"Model: {self.model_name}")
        logger.info(f"Strategy: {'Chain-of-Thought' if use_cot else 'Direct'}")
        logger.info(f"{'='*60}\n")

        return final_results

    def _evaluate_response(
        self,
        response: str,
        ground_truth: str,
        dataset_name: str
    ) -> bool:
        """
        Simple evaluation logic (can be enhanced for specific benchmarks).

        Note: For production use, integrate with the actual benchmark evaluators.
        """
        if not response:
            return False

        # Simple string matching (simplified - actual logic should use benchmark evaluators)
        response_lower = response.lower().strip()
        truth_lower = str(ground_truth).lower().strip()

        # For now, simple containment check
        # TODO: Use actual benchmark evaluation logic
        return truth_lower in response_lower

    def get_costs(self) -> Dict[str, float]:
        """Get the total costs of inference"""
        costs = self.llm.get_costs()
        return {
            "total_prompt_tokens": costs.total_prompt_tokens,
            "total_completion_tokens": costs.total_completion_tokens,
            "total_cost": costs.total_cost,
            "total_budget": costs.total_budget
        }


async def main():
    parser = argparse.ArgumentParser(
        description="Vanilla Model Inference - Simple Baseline for Comparison"
    )
    parser.add_argument(
        "--dataset",
        type=str,
        default="GSM8K",
        choices=["HumanEval", "MATH", "GSM8K"],
        help="Dataset to evaluate on"
    )
    parser.add_argument(
        "--model_name",
        type=str,
        default=None,
        help="Model name (defaults to config2.yaml llm.model)"
    )
    parser.add_argument(
        "--sample",
        type=int,
        default=10,
        help="Number of samples to evaluate"
    )
    parser.add_argument(
        "--use_cot",
        type=bool,
        default=True,
        help="Use chain-of-thought prompting"
    )
    parser.add_argument(
        "--use_test_split",
        type=bool,
        default=True,
        help="Use test split (True = same as MaAS --is_test True, False = validation split)"
    )
    parser.add_argument(
        "--output_file",
        type=str,
        default="results/vanilla_baseline.json",
        help="Output file for results"
    )
    parser.add_argument(
        "--config_path",
        type=str,
        default="config/config2.yaml",
        help="Path to config file"
    )

    args = parser.parse_args()

    logger.info("Loading configuration from config2.yaml")

    # Create vanilla inference instance with specified model
    vanilla = VanillaInference(model_name=args.model_name)

    # Run evaluation
    results = await vanilla.run_on_dataset(
        dataset_name=args.dataset,
        num_samples=args.sample,
        use_cot=args.use_cot,
        use_test_split=args.use_test_split,
        output_file=args.output_file
    )

    # Print costs
    costs = vanilla.get_costs()
    logger.info(f"\nCost Summary:")
    logger.info(f"  Prompt Tokens: {costs['total_prompt_tokens']}")
    logger.info(f"  Completion Tokens: {costs['total_completion_tokens']}")
    logger.info(f"  Total Cost: ${costs['total_cost']:.4f}")

    return results


if __name__ == "__main__":
    asyncio.run(main())
