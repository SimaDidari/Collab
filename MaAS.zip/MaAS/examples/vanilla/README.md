# Vanilla Model Inference - Simple Baseline

This directory contains standalone scripts for **vanilla (baseline) inference** without multi-agent architecture search. Use these scripts to compare simple, direct LLM inference against MaAS's optimized operator selection approach.

---

## 🚀 Quick Reference Card

```bash
# 1. Verify setup (30 seconds)
cd /home/davoud/MaAS && python examples/vanilla/test_imports.py

# 2. Test your LLM (1 minute)
python -m examples.vanilla.simple_example

# 3. Run small benchmark (2-3 minutes)
python -m examples.vanilla.vanilla_inference --dataset GSM8K --sample 5

# 4. Full evaluation (10 minutes)
python -m examples.vanilla.vanilla_inference \
    --dataset GSM8K \
    --sample 100 \
    --model_name qwen3 \
    --output_file results/my_results.json

# 5. Compare with MaAS
python -m examples.maas.optimize --dataset GSM8K --sample 100 --exec_model_name "qwen3" --is_test True
```

**Your Configuration**: Model `qwen3` at `http://105.144.47.80:8002/v1`

---

## 📋 Table of Contents

- [Quick Reference Card](#-quick-reference-card)
- [Overview](#overview)
- [Key Differences from MaAS](#key-differences-from-maas)
- [Installation & Setup](#installation--setup)
- [Quick Start](#quick-start)
- [Configuration](#configuration)
- [Complete Usage Guide](#complete-usage-guide)
- [Command-Line Arguments](#command-line-arguments)
- [Output Format](#output-format)
- [Comparison: Vanilla vs MaAS](#comparison-vanilla-baseline-vs-maas)
- [Common Use Cases](#common-use-cases)
- [Code Structure](#code-structure)
- [Troubleshooting](#troubleshooting)
- [Performance Tips](#performance-tips)
- [Citation](#citation)

---

## Overview

- **vanilla_inference.py**: Full benchmark evaluation script with CoT support
- **simple_example.py**: Minimal usage example for basic questions
- **test_imports.py**: Verify installation and configuration
- **README.md**: This documentation

## Key Differences from MaAS

| Feature | Vanilla Baseline | MaAS Architecture Search |
|---------|-----------------|-------------------------|
| **Approach** | Direct LLM call | Multi-layer operator selection |
| **Orchestration** | Single-pass generation | Dynamic operator graph |
| **Optimization** | None | Neural controller learning |
| **Adaptivity** | Fixed strategy | Query-specific customization |
| **Use Case** | Simple baseline comparison | Optimized performance |

## Installation & Setup

### Prerequisites

1. You must have MaAS installed and configured
2. Your `config/config2.yaml` must contain LLM configuration
3. Navigate to the MaAS root directory before running scripts

### Verify Setup

First, verify everything is working:

```bash
cd /home/davoud/MaAS
python examples/vanilla/test_imports.py
```

Expected output:
```
Testing imports...
✓ maas.configs.llm_config imported
✓ maas.provider.llm_provider_registry imported
✓ maas.logs imported
✓ maas.configs.models_config imported

Testing configuration loading...
✓ Configuration loaded successfully
  Available models: ['qwen3']

All imports successful!
```

## Quick Start

### 1. Simple Example (Start Here!)

Run basic questions with your configured LLM:

```bash
cd /home/davoud/MaAS
python -m examples.vanilla.simple_example
```

This will:
- Load your LLM from `config/config2.yaml` (uses your qwen3 model)
- Run 3 example questions (math, word problem, code generation)
- Show responses and token usage
- Takes about 30 seconds

**Example Output:**
```
Loaded LLM: llm_base_model from http://105.144.47.80:8002/v1

Question: What is 25 * 37?
Response: 925

Question: A store has 120 apples...
Response: 37 apples are left

Cost Summary:
  Prompt Tokens: 150
  Completion Tokens: 200
  Total Cost: $0.0005
```

### 2. View All Options

See all available command-line options:

```bash
python -m examples.vanilla.vanilla_inference --help
```

### 3. Benchmark Evaluation

**Important:** Benchmark evaluation requires dataset files in `maas/ext/maas/data/`. If these files are not available, the script will gracefully fail but you can still use the simple example above.

#### Start Small (Recommended):

```bash
# Test with just 5 samples first
cd /home/davoud/MaAS
python -m examples.vanilla.vanilla_inference \
    --dataset GSM8K \
    --sample 5 \
    --output_file results/vanilla_test.json
```

#### Full Evaluation Examples:

```bash
cd /home/davoud/MaAS

# GSM8K (Math word problems) - 50 samples
python -m examples.vanilla.vanilla_inference \
    --dataset GSM8K \
    --sample 50 \
    --use_cot True \
    --output_file results/vanilla_gsm8k_50.json

# HumanEval (Code generation) - 50 samples
python -m examples.vanilla.vanilla_inference \
    --dataset HumanEval \
    --sample 50 \
    --output_file results/vanilla_humaneval_50.json

# MATH (Advanced math) - 50 samples
python -m examples.vanilla.vanilla_inference \
    --dataset MATH \
    --sample 50 \
    --output_file results/vanilla_math_50.json

# Large-scale evaluation - 200 samples
python -m examples.vanilla.vanilla_inference \
    --dataset GSM8K \
    --sample 200 \
    --output_file results/vanilla_gsm8k_200.json
```

## Configuration

The scripts automatically load your `config/config2.yaml` configuration. Your current setup:

```yaml
llm:
  api_type: "openai"
  base_url: "http://105.144.47.80:8002/v1"
  api_key: "EMPTY"
  model: "llm_base_model"
  timeout: 600

models:
  "qwen3":
    api_type: "openai"
    base_url: "http://105.144.47.80:8002/v1"
    api_key: "EMPTY"
    model: "llm_base_model"
    timeout: 600
```

### Using Different Models

The scripts will automatically detect and use available models from your config.

**Option 1: Use default model (automatic)**
```bash
# Uses first available model from config (qwen3 in your case)
python -m examples.vanilla.vanilla_inference \
    --dataset GSM8K \
    --sample 20
```

**Option 2: Specify a model explicitly**
```bash
# Use specific model from config
python -m examples.vanilla.vanilla_inference \
    --dataset GSM8K \
    --model_name "qwen3" \
    --sample 20
```

**Option 3: Add more models to config**

Edit `config/config2.yaml` to add additional models:
```yaml
models:
  "qwen3":
    api_type: "openai"
    base_url: "http://105.144.47.80:8002/v1"
    api_key: "EMPTY"
    model: "llm_base_model"
    timeout: 600

  "gpt-4":
    api_type: "openai"
    base_url: "https://api.openai.com/v1"
    api_key: "your-api-key-here"
    model: "gpt-4"
    timeout: 600
```

Then use it:
```bash
python -m examples.vanilla.vanilla_inference \
    --dataset GSM8K \
    --model_name "gpt-4" \
    --sample 20
```

## Complete Usage Guide

### Step-by-Step: First Time Usage

**Step 1: Verify Installation**
```bash
cd /home/davoud/MaAS
python examples/vanilla/test_imports.py
```

**Step 2: Run Simple Example**
```bash
python -m examples.vanilla.simple_example
```
This tests basic LLM connectivity and shows example outputs.

**Step 3: Try Small Benchmark**
```bash
python -m examples.vanilla.vanilla_inference \
    --dataset GSM8K \
    --sample 5
```

**Step 4: Review Results**
Results are saved to `results/vanilla_baseline.json` by default. Check this file to see:
- Accuracy score
- Individual question responses
- Token usage statistics

**Step 5: Scale Up**
```bash
python -m examples.vanilla.vanilla_inference \
    --dataset GSM8K \
    --sample 50 \
    --output_file results/gsm8k_50_samples.json
```

### Command-Line Arguments

#### vanilla_inference.py

| Argument | Type | Default | Description |
|----------|------|---------|-------------|
| `--dataset` | str | GSM8K | Dataset to evaluate: `HumanEval`, `MATH`, or `GSM8K` |
| `--model_name` | str | auto-detect | Model name from config (e.g., "qwen3") |
| `--sample` | int | 10 | Number of samples to evaluate |
| `--use_cot` | bool | True | Use chain-of-thought prompting |
| `--output_file` | str | results/vanilla_baseline.json | Path to save results |
| `--config_path` | str | config/config2.yaml | Path to config file |

#### Examples with Different Arguments

```bash
# Disable Chain-of-Thought
python -m examples.vanilla.vanilla_inference \
    --dataset GSM8K \
    --sample 20 \
    --use_cot False

# Specify output location
python -m examples.vanilla.vanilla_inference \
    --dataset MATH \
    --sample 100 \
    --output_file /path/to/my_results.json

# Use specific model
python -m examples.vanilla.vanilla_inference \
    --dataset HumanEval \
    --sample 30 \
    --model_name qwen3

# Large evaluation
python -m examples.vanilla.vanilla_inference \
    --dataset GSM8K \
    --sample 500 \
    --output_file results/large_eval.json
```

## Output Format

Results are saved as JSON with the following structure:

```json
{
  "dataset": "GSM8K",
  "total_samples": 50,
  "correct": 35,
  "accuracy": 70.0,
  "use_cot": true,
  "model": "llm_base_model",
  "results": [
    {
      "index": 0,
      "question": "...",
      "response": "...",
      "ground_truth": "...",
      "correct": true
    }
  ]
}
```

## Comparison: Vanilla Baseline vs. MaAS

### Why Compare?

Vanilla inference provides a baseline to measure the improvement from MaAS's architecture search:
- **Vanilla**: Simple, direct LLM inference (what you get with standard prompting)
- **MaAS**: Intelligent operator selection optimized for each query type

### Complete Comparison Workflow

#### Step 1: Run Vanilla Baseline

```bash
cd /home/davoud/MaAS

# Run vanilla baseline on GSM8K with 100 samples
python -m examples.vanilla.vanilla_inference \
    --dataset GSM8K \
    --sample 100 \
    --model_name qwen3 \
    --output_file results/vanilla_gsm8k_100.json
```

This will output something like:
```
Vanilla Inference Results on GSM8K
==================================================
Total Samples: 100
Correct: 65
Accuracy: 65.00%
==================================================
```

#### Step 2: Run MaAS Architecture Search

```bash
# Run MaAS with the same model and dataset
python -m examples.maas.optimize \
    --dataset GSM8K \
    --sample 100 \
    --exec_model_name "qwen3" \
    --is_test True
```

Expected MaAS output might show:
```
MaAS Optimized Results on GSM8K
==================================================
Total Samples: 100
Correct: 78
Accuracy: 78.00%
==================================================
```

#### Step 3: Analyze the Improvement

| Metric | Vanilla Baseline | MaAS Optimized | Improvement |
|--------|-----------------|----------------|-------------|
| Accuracy | 65% | 78% | +13% (example) |
| Avg Tokens/Query | 450 | 380 | -15% more efficient |
| Approach | Fixed CoT | Dynamic operators | Adaptive |

### Metrics to Compare

1. **Accuracy**: Correct predictions / Total samples
2. **Token Efficiency**: Average tokens used per query
3. **Cost**: Total API cost for the evaluation
4. **Time**: Total execution time

### Real-World Comparison Example

```bash
# Terminal 1: Run vanilla baseline
cd /home/davoud/MaAS
time python -m examples.vanilla.vanilla_inference \
    --dataset GSM8K \
    --sample 200 \
    --model_name qwen3 \
    --output_file results/vanilla_baseline_200.json

# Terminal 2: Run MaAS
time python -m examples.maas.optimize \
    --dataset GSM8K \
    --sample 200 \
    --exec_model_name "qwen3" \
    --is_test True

# Compare the JSON output files
python -c "
import json
with open('results/vanilla_baseline_200.json') as f:
    vanilla = json.load(f)
print(f'Vanilla Accuracy: {vanilla[\"accuracy\"]:.2f}%')
"
```

## Common Use Cases

### Use Case 1: Quick LLM Testing
**Goal**: Test if your LLM server is working correctly

```bash
cd /home/davoud/MaAS
python -m examples.vanilla.simple_example
```
**Time**: ~30 seconds
**Output**: Simple Q&A responses to verify connectivity

---

### Use Case 2: Establish Baseline Performance
**Goal**: Get baseline accuracy before using MaAS optimization

```bash
cd /home/davoud/MaAS

# Step 1: Run vanilla baseline (your current approach)
python -m examples.vanilla.vanilla_inference \
    --dataset GSM8K \
    --sample 100 \
    --model_name qwen3 \
    --output_file results/baseline_gsm8k.json

# Step 2: Note the accuracy from output
# Example: "Accuracy: 65.00%"
```
**Time**: ~5-10 minutes for 100 samples
**Output**: JSON file with accuracy and detailed results

---

### Use Case 3: Full Vanilla vs MaAS Comparison
**Goal**: Compare vanilla inference against MaAS architecture search

```bash
cd /home/davoud/MaAS

# Run vanilla baseline
python -m examples.vanilla.vanilla_inference \
    --dataset GSM8K \
    --sample 200 \
    --model_name qwen3 \
    --output_file results/vanilla_gsm8k_200.json

# Run MaAS optimized (after training)
python -m examples.maas.optimize \
    --dataset GSM8K \
    --sample 200 \
    --exec_model_name "qwen3" \
    --is_test True

# Compare results
echo "Vanilla results:"
cat results/vanilla_gsm8k_200.json | grep accuracy
```
**Time**: ~20-30 minutes total
**Output**: Side-by-side comparison of accuracy and efficiency

---

### Use Case 4: Test Different Datasets
**Goal**: Evaluate your model on multiple benchmarks

```bash
cd /home/davoud/MaAS

# Math word problems
python -m examples.vanilla.vanilla_inference \
    --dataset GSM8K \
    --sample 50 \
    --output_file results/vanilla_gsm8k.json

# Advanced math
python -m examples.vanilla.vanilla_inference \
    --dataset MATH \
    --sample 50 \
    --output_file results/vanilla_math.json

# Code generation
python -m examples.vanilla.vanilla_inference \
    --dataset HumanEval \
    --sample 50 \
    --output_file results/vanilla_humaneval.json
```
**Time**: ~30 minutes total
**Output**: Three JSON files with results for each benchmark

---

### Use Case 5: Compare CoT vs Direct Inference
**Goal**: Test if chain-of-thought improves performance

```bash
cd /home/davoud/MaAS

# Direct inference (no CoT)
python -m examples.vanilla.vanilla_inference \
    --dataset GSM8K \
    --sample 50 \
    --use_cot False \
    --output_file results/direct_gsm8k.json

# Chain-of-thought inference
python -m examples.vanilla.vanilla_inference \
    --dataset GSM8K \
    --sample 50 \
    --use_cot True \
    --output_file results/cot_gsm8k.json

# Compare
echo "Direct:" && cat results/direct_gsm8k.json | grep accuracy
echo "CoT:" && cat results/cot_gsm8k.json | grep accuracy
```
**Time**: ~20 minutes
**Output**: Comparison of CoT vs direct inference accuracy

---

### Use Case 6: Cost Analysis
**Goal**: Measure token usage and costs

```bash
cd /home/davoud/MaAS

# Run evaluation and capture cost info
python -m examples.vanilla.vanilla_inference \
    --dataset GSM8K \
    --sample 100 \
    --output_file results/cost_analysis.json 2>&1 | tee cost_log.txt

# Check the log for:
# - Prompt Tokens
# - Completion Tokens
# - Total Cost
```
**Time**: ~10 minutes
**Output**: Cost metrics in log file

## Code Structure

### VanillaInference Class

```python
from examples.vanilla.vanilla_inference import VanillaInference

# Initialize with LLM config
vanilla = VanillaInference(llm_config)

# Simple generation
response = await vanilla.simple_generate("What is 2+2?")

# Chain-of-thought generation
response = await vanilla.simple_cot_generate("Complex problem here")

# Run on benchmark
results = await vanilla.run_on_dataset(
    dataset_name="GSM8K",
    num_samples=50,
    use_cot=True
)
```

## Extending Vanilla Inference

To add custom prompting strategies:

```python
# Add to vanilla_inference.py

async def custom_strategy(self, question: str) -> str:
    """Your custom inference strategy"""
    prompt = f"[Custom instructions]\n\n{question}"
    return await self.llm.aask(prompt)
```

## Troubleshooting

### Issue 1: Import Errors

**Problem**: `ModuleNotFoundError: No module named 'maas'`

**Solution**: Make sure you're in the MaAS root directory
```bash
cd /home/davoud/MaAS
python -m examples.vanilla.vanilla_inference
```

---

### Issue 2: LLM Connection Failed

**Problem**: "Connection refused" or timeout errors

**Solution**: Check your LLM server is running
```bash
# Verify server is accessible
curl http://105.144.47.80:8002/v1/models

# Check config2.yaml has correct base_url
cat config/config2.yaml | grep base_url

# Test with simple example first
python -m examples.vanilla.simple_example
```

---

### Issue 3: Model Not Found

**Problem**: `Model 'xyz' not found in config2.yaml`

**Solution**: Check available models
```bash
# List available models
python -c "
from maas.configs.models_config import ModelsConfig
config = ModelsConfig.default()
print('Available models:', list(config.models.keys()))
"

# Or let script auto-detect
python -m examples.vanilla.vanilla_inference --dataset GSM8K --sample 5
```

---

### Issue 4: Dataset Not Found

**Problem**: `Dataset file not found: maas/ext/maas/data/GSM8K/test.jsonl`

**Solution**: Dataset files are optional for simple_example.py. For benchmark evaluation:
```bash
# Check if data exists
ls -la maas/ext/maas/data/

# If missing, you can still test with simple_example
python -m examples.vanilla.simple_example

# Or download datasets following MaAS documentation
```

---

### Issue 5: Slow Performance

**Problem**: Evaluation taking too long

**Solution**: Start with small samples
```bash
# Use --sample to limit evaluation size
python -m examples.vanilla.vanilla_inference \
    --dataset GSM8K \
    --sample 5  # Start small!

# Gradually increase
python -m examples.vanilla.vanilla_inference \
    --dataset GSM8K \
    --sample 20
```

---

### Issue 6: Out of Memory

**Problem**: System running out of memory

**Solution**: Process in smaller batches
```bash
# Run multiple small evaluations
for i in {1..5}; do
    python -m examples.vanilla.vanilla_inference \
        --dataset GSM8K \
        --sample 20 \
        --output_file results/batch_$i.json
done
```

---

### Getting Help

If you encounter other issues:

1. **Check logs**: Look for error messages in the console output
2. **Verify config**: Run `python examples/vanilla/test_imports.py`
3. **Test connectivity**: Run `python -m examples.vanilla.simple_example`
4. **Check MaAS docs**: See main MaAS README.md
5. **File an issue**: Report at the MaAS GitHub repository

## Performance Tips

1. **Batch Processing**: Modify the script to process multiple samples in parallel
2. **Caching**: Add response caching to avoid redundant API calls
3. **Sampling**: Start with small samples (10-20) before running full evaluations
4. **Streaming**: Enable streaming for faster feedback during development

## Citation

If you use this vanilla baseline in your research, please cite the MaAS paper:

```bibtex
@inproceedings{maas2025,
  title={MaAS: Multi-agent Architecture Search via Agentic Supernet},
  booktitle={ICML},
  year={2025}
}
```

## Support

- **Issues**: Report at the main MaAS repository
- **Documentation**: See main MaAS README.md
- **Examples**: Check simple_example.py for basic usage
