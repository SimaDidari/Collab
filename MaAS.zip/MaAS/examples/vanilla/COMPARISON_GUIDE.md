# Vanilla vs MaAS - Complete Comparison Guide

**Your exact command matched with vanilla baseline**

This guide shows how to run vanilla inference with the **exact same data split** as your MaAS test command.

---

## Your MaAS Command

```bash
python -m examples.maas.optimize \
    --dataset HumanEval \
    --round 1 \
    --sample 4 \
    --exec_model_name "gpt-4o-mini" \
    --is_test True
```

**What MaAS uses**:
- Dataset: `maas/ext/maas/data/humaneval_test.jsonl`
- Samples: **131** (all samples in test split)
- Model: gpt-4o-mini
- Mode: Test/Evaluation (not training)

---

## Matching Vanilla Command

```bash
python -m examples.vanilla.vanilla_inference \
    --dataset HumanEval \
    --sample 131 \
    --model_name qwen3 \
    --use_test_split True \
    --output_file results/vanilla_humaneval_131.json
```

**What Vanilla uses**:
- Dataset: `maas/ext/maas/data/humaneval_test.jsonl` ✅ SAME FILE
- Samples: **131** (all samples in test split) ✅ SAME DATA
- Model: qwen3 (your model from config)
- Mode: Test split (matches MaAS --is_test True)

---

## Step-by-Step Comparison

### Step 1: Run Vanilla Baseline

```bash
cd /home/davoud/MaAS

python -m examples.vanilla.vanilla_inference \
    --dataset HumanEval \
    --sample 131 \
    --model_name qwen3 \
    --use_test_split True \
    --output_file results/vanilla_humaneval_test.json
```

**Expected output:**
```
============================================================
Vanilla Inference on HumanEval - TEST Split
============================================================
Data Split: TEST (same as MaAS --is_test True)
Total samples in split: 131
Evaluating: 131 samples
Model: qwen3
Strategy: Chain-of-Thought generation
============================================================

Progress: 10/131 | Accuracy: 65.00%
Progress: 20/131 | Accuracy: 63.50%
...
Progress: 131/131 | Accuracy: 64.89%

============================================================
FINAL RESULTS: HumanEval - TEST Split
============================================================
Split: TEST (use_test_split=True)
Total samples in split: 131
Evaluated: 131 samples
Correct: 85
Accuracy: 64.89%
Model: qwen3
Strategy: Chain-of-Thought
============================================================

Results saved to results/vanilla_humaneval_test.json
```

### Step 2: Run MaAS

```bash
python -m examples.maas.optimize \
    --dataset HumanEval \
    --round 1 \
    --sample 4 \
    --exec_model_name "qwen3" \
    --is_test True
```

**Note**: Use `qwen3` (your model) instead of `gpt-4o-mini` for fair comparison.

### Step 3: Compare Results

```bash
# Check vanilla results
cat results/vanilla_humaneval_test.json | grep -E "accuracy|correct|evaluated"

# Output example:
#   "evaluated_samples": 131,
#   "correct": 85,
#   "accuracy": 64.89,

# Check MaAS results from logs
# Look for: "Average score on HumanEval dataset: 0.XXXXX"
```

### Step 4: Analysis

Create a comparison table:

| Metric | Vanilla Baseline | MaAS Optimized | Improvement |
|--------|-----------------|----------------|-------------|
| Dataset | HumanEval Test (131 samples) | HumanEval Test (131 samples) | ✅ Same |
| Correct | 85 (example) | 95 (example) | +10 |
| Accuracy | 64.89% | 72.52% | +7.63% |
| Approach | Fixed CoT | Dynamic operators | Adaptive |

---

## Quick Commands

### Recommended: Full Test Set

```bash
cd /home/davoud/MaAS

# Vanilla (takes ~15-20 minutes for 131 samples)
python -m examples.vanilla.vanilla_inference \
    --dataset HumanEval \
    --sample 131 \
    --model_name qwen3 \
    --output_file results/vanilla_humaneval_full.json

# MaAS
python -m examples.maas.optimize \
    --dataset HumanEval \
    --exec_model_name "qwen3" \
    --is_test True
```

### Quick Test: First 10 Samples

```bash
cd /home/davoud/MaAS

# Vanilla (takes ~2 minutes)
python -m examples.vanilla.vanilla_inference \
    --dataset HumanEval \
    --sample 10 \
    --model_name qwen3

# Note: MaAS always uses full test split, so partial comparison won't be exact
```

### Different Datasets

```bash
# GSM8K
python -m examples.vanilla.vanilla_inference \
    --dataset GSM8K \
    --model_name qwen3 \
    --use_test_split True

# MATH
python -m examples.vanilla.vanilla_inference \
    --dataset MATH \
    --model_name qwen3 \
    --use_test_split True
```

---

## Understanding the Data Splits

### What `--is_test True` means in MaAS:

```python
# From maas/ext/maas/scripts/evaluator.py line 60-63
def _get_data_path(self, dataset: DatasetType, test: bool) -> str:
    base_path = f"maas/ext/maas/data/{dataset.lower()}"
    return f"{base_path}_test.jsonl" if test else f"{base_path}_validate.jsonl"
```

- `--is_test True` → uses `humaneval_test.jsonl` (131 samples)
- `--is_test False` → uses `humaneval_validate.jsonl` (33 samples)

### What `--use_test_split True` means in Vanilla:

```python
# From examples/vanilla/vanilla_inference.py
if use_test_split:
    data_file = data_dir / "humaneval_test.jsonl"  # Same as MaAS!
else:
    data_file = data_dir / "humaneval_validate.jsonl"
```

- `--use_test_split True` → uses `humaneval_test.jsonl` (131 samples) ✅
- `--use_test_split False` → uses `humaneval_validate.jsonl` (33 samples)

**Result**: Both use the EXACT same file!

---

## Verification Checklist

Before comparing results, verify:

- [ ] Both use `humaneval_test.jsonl` file
- [ ] Both evaluate 131 samples (full test set)
- [ ] Both use the same model (qwen3)
- [ ] Vanilla shows: "Data Split: TEST (same as MaAS --is_test True)"
- [ ] MaAS shows: Uses test data (check logs)

### Verification Commands:

```bash
# Check vanilla is using correct file (look at logs)
python -m examples.vanilla.vanilla_inference \
    --dataset HumanEval \
    --sample 5 | grep "Data Split"

# Expected: "Data Split: TEST (same as MaAS --is_test True)"

# Check sample counts
wc -l /home/davoud/MaAS/maas/ext/maas/data/humaneval_test.jsonl
# Expected: 131

# Check vanilla JSON output
cat results/vanilla_humaneval_test.json | grep -E "split|total_in_split"
# Expected:
#   "split": "TEST",
#   "total_in_split": 131,
```

---

## Common Questions

### Q: Why does MaAS have `--sample 4` but evaluate 131 samples?

A: In MaAS, `--sample` controls the training behavior (number of samples per optimization round), **not** the test set size. When `--is_test True`, MaAS always evaluates on the full test split.

### Q: Can I compare on a subset of data?

A: Yes, but it's not a perfect comparison because:
- Vanilla: Evaluates first N samples
- MaAS: Always uses full test set

For true apples-to-apples comparison, use the full test set (131 samples for HumanEval).

### Q: What if I want to use the validation split?

A: Use `--use_test_split False` in vanilla:

```bash
python -m examples.vanilla.vanilla_inference \
    --dataset HumanEval \
    --sample 33 \
    --use_test_split False
```

This matches MaAS training data (`--is_test False`).

### Q: How do I know the comparison is fair?

A: Check these match:
1. ✅ Same data file (humaneval_test.jsonl)
2. ✅ Same number of samples (131)
3. ✅ Same model (qwen3)
4. ✅ Vanilla logs show: "same as MaAS --is_test True"

---

## Example Complete Workflow

```bash
#!/bin/bash
cd /home/davoud/MaAS

echo "=== Running Vanilla Baseline ==="
python -m examples.vanilla.vanilla_inference \
    --dataset HumanEval \
    --sample 131 \
    --model_name qwen3 \
    --use_test_split True \
    --output_file results/vanilla_humaneval_131.json

echo ""
echo "=== Vanilla Results ==="
cat results/vanilla_humaneval_131.json | grep -E "accuracy|correct|evaluated_samples"

echo ""
echo "=== Running MaAS Optimized ==="
python -m examples.maas.optimize \
    --dataset HumanEval \
    --round 1 \
    --sample 4 \
    --exec_model_name "qwen3" \
    --is_test True

echo ""
echo "=== Comparison Complete ==="
echo "Check logs above for MaAS accuracy"
echo "Vanilla accuracy in: results/vanilla_humaneval_131.json"
```

---

## Summary

✅ **Vanilla inference now supports exact same data splits as MaAS**

✅ **For your specific command**:
- MaAS: `--is_test True` → uses `humaneval_test.jsonl` (131 samples)
- Vanilla: `--use_test_split True` → uses `humaneval_test.jsonl` (131 samples)
- **Result**: Perfect match!

✅ **To compare**:
```bash
# Vanilla
python -m examples.vanilla.vanilla_inference \
    --dataset HumanEval --sample 131 --model_name qwen3

# MaAS
python -m examples.maas.optimize \
    --dataset HumanEval --exec_model_name "qwen3" --is_test True
```

✅ **Both evaluate on the exact same 131 HumanEval test samples**

---

## More Information

- **Data splits details**: See [DATA_SPLITS.md](DATA_SPLITS.md)
- **Full documentation**: See [README.md](README.md)
- **Quick start**: See [QUICKSTART.md](QUICKSTART.md)

---

**Ready to run?** Copy the commands above and start your comparison!
