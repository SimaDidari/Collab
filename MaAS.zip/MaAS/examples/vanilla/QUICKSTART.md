# Vanilla Inference - Quick Start Guide

**5-Minute Setup**: Get started with vanilla baseline inference

---

## Step 1: Verify Installation (30 seconds)

```bash
cd /home/davoud/MaAS
python examples/vanilla/test_imports.py
```

✅ Expected output: "All imports successful!"

---

## Step 2: Test Your LLM (1 minute)

```bash
python -m examples.vanilla.simple_example
```

✅ You should see responses to 3 example questions

---

## Step 3: Run Your First Benchmark (2-3 minutes)

```bash
python -m examples.vanilla.vanilla_inference \
    --dataset GSM8K \
    --sample 5 \
    --output_file results/test.json
```

✅ Results saved to `results/test.json`

---

## Step 4: Scale Up (10 minutes)

```bash
python -m examples.vanilla.vanilla_inference \
    --dataset GSM8K \
    --sample 100 \
    --model_name qwen3 \
    --output_file results/gsm8k_100.json
```

✅ Full evaluation with 100 samples

---

## Step 5: Compare with MaAS (optional)

```bash
# Your vanilla baseline (from Step 4)
# Accuracy: XX.XX%

# Now run MaAS
python -m examples.maas.optimize \
    --dataset GSM8K \
    --sample 100 \
    --exec_model_name "qwen3" \
    --is_test True

# Compare the accuracy improvement!
```

---

## Common Commands

### Basic Usage
```bash
# Simple test
python -m examples.vanilla.simple_example

# Small benchmark
python -m examples.vanilla.vanilla_inference --dataset GSM8K --sample 10

# Full evaluation
python -m examples.vanilla.vanilla_inference --dataset GSM8K --sample 100
```

### Different Datasets
```bash
# Math word problems
python -m examples.vanilla.vanilla_inference --dataset GSM8K --sample 50

# Advanced math
python -m examples.vanilla.vanilla_inference --dataset MATH --sample 50

# Code generation
python -m examples.vanilla.vanilla_inference --dataset HumanEval --sample 50
```

### Customization
```bash
# Disable Chain-of-Thought
python -m examples.vanilla.vanilla_inference \
    --dataset GSM8K \
    --sample 50 \
    --use_cot False

# Custom output location
python -m examples.vanilla.vanilla_inference \
    --dataset GSM8K \
    --sample 50 \
    --output_file /path/to/results.json

# Specify model
python -m examples.vanilla.vanilla_inference \
    --dataset GSM8K \
    --sample 50 \
    --model_name qwen3
```

---

## Your Configuration

- **Model**: qwen3 (llm_base_model)
- **Server**: http://105.144.47.80:8002/v1
- **API Type**: OpenAI-compatible
- **Working Directory**: /home/davoud/MaAS

---

## Output Files

Results are saved as JSON:

```json
{
  "dataset": "GSM8K",
  "total_samples": 100,
  "correct": 65,
  "accuracy": 65.0,
  "use_cot": true,
  "model": "llm_base_model",
  "results": [...]
}
```

**Location**: `results/vanilla_baseline.json` (default) or your custom path

---

## Troubleshooting

### Problem: Import errors
**Solution**: Make sure you're in `/home/davoud/MaAS` directory

### Problem: Connection failed
**Solution**: Check your LLM server is running:
```bash
curl http://105.144.47.80:8002/v1/models
```

### Problem: Evaluation too slow
**Solution**: Start with smaller samples:
```bash
python -m examples.vanilla.vanilla_inference --dataset GSM8K --sample 5
```

### Problem: Dataset not found
**Solution**: Use `simple_example.py` instead:
```bash
python -m examples.vanilla.simple_example
```

---

## Next Steps

1. ✅ Run simple_example.py to test connectivity
2. ✅ Run small benchmark (5-10 samples)
3. ✅ Run full evaluation (100+ samples)
4. ✅ Compare with MaAS architecture search
5. ✅ Analyze results and token efficiency

---

## Need More Help?

- **Full Documentation**: See [README.md](README.md)
- **MaAS Documentation**: See main MaAS README
- **Issues**: Check console output for error messages

---

## Summary

```bash
# Everything you need in 4 commands:

cd /home/davoud/MaAS

# 1. Test setup
python examples/vanilla/test_imports.py

# 2. Test LLM
python -m examples.vanilla.simple_example

# 3. Run baseline
python -m examples.vanilla.vanilla_inference --dataset GSM8K --sample 100

# 4. Compare with MaAS
python -m examples.maas.optimize --dataset GSM8K --sample 100 --exec_model_name "qwen3" --is_test True
```

That's it! You're ready to use vanilla inference as a baseline for comparison.
