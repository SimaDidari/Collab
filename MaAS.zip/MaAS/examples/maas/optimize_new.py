#!/usr/bin/env python
"""
Monitor script to run the optimizer with better visibility
Save this as monitor_optimize.py and run it instead of the direct command
"""

import subprocess
import sys
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TaskProgressColumn
from rich.live import Live
from rich.table import Table
from rich.panel import Panel
from datetime import datetime
import re
import threading
import time

console = Console()

def parse_progress_line(line):
    """Extract progress information from log lines"""
    patterns = {
        'batch': r'batch (\d+)',
        'repetition': r'[Rr]epetition (\d+)',
        'percentage': r'(\d+)%',
        'items': r'(\d+)/(\d+)',
    }
    
    info = {}
    for key, pattern in patterns.items():
        match = re.search(pattern, line)
        if match:
            info[key] = match.groups()
    
    return info

def run_optimizer_with_monitoring(cmd_args):
    """Run the optimizer command with real-time monitoring"""
    
    # Build the command
    cmd = [sys.executable, "-m", "examples.maas.optimize"] + cmd_args
    
    console.print(Panel.fit(
        f"[bold cyan]MAAS Optimizer Monitor[/bold cyan]\n"
        f"[dim]Started at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}[/dim]\n"
        f"[dim]Command: {' '.join(cmd)}[/dim]",
        title="Initialization"
    ))
    
    # Create a table for status display
    status_table = Table(title="Current Status", show_header=True, header_style="bold magenta")
    status_table.add_column("Metric", style="cyan")
    status_table.add_column("Value", style="green")
    
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TaskProgressColumn(),
        console=console,
        refresh_per_second=4
    ) as progress:
        
        # Add main task
        main_task = progress.add_task("[cyan]Overall Progress", total=100)
        batch_task = progress.add_task("[yellow]Current Batch", total=100)
        
        # Start the subprocess
        process = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            universal_newlines=True,
            bufsize=1
        )
        
        lines_buffer = []
        api_calls = 0
        warnings = 0
        current_batch = 0
        current_repetition = 0
        
        # Process output line by line
        for line in iter(process.stdout.readline, ''):
            if line:
                line = line.strip()
                lines_buffer.append(line)
                
                # Keep only last 10 lines in buffer
                if len(lines_buffer) > 10:
                    lines_buffer.pop(0)
                
                # Parse the line for progress info
                info = parse_progress_line(line)
                
                # Update progress based on line content
                if "INFO" in line:
                    console.print(f"[green]ℹ[/green] {line}")
                elif "WARNING" in line:
                    warnings += 1
                    if "Finished call" in line:
                        api_calls += 1
                        # Extract API call time
                        time_match = re.search(r'after ([\d.]+)\(s\)', line)
                        if time_match:
                            call_time = time_match.group(1)
                            console.print(f"[yellow]⚡[/yellow] API call completed in {call_time}s")
                elif "ERROR" in line:
                    console.print(f"[red]✗[/red] {line}", style="bold red")
                elif "batch" in line.lower():
                    current_batch += 1
                    console.print(f"[blue]📦[/blue] Processing {line}")
                
                # Update progress bars
                if info.get('percentage'):
                    pct = int(info['percentage'][0])
                    progress.update(batch_task, completed=pct)
                
                if info.get('items'):
                    current, total = map(int, info['items'])
                    progress.update(main_task, completed=(current/total)*100)
        
        process.wait()
        
        # Final status
        console.print("\n")
        if process.returncode == 0:
            console.print(Panel.fit(
                f"[bold green]✓ Optimization Completed Successfully![/bold green]\n"
                f"[dim]Total API calls: {api_calls}[/dim]\n"
                f"[dim]Warnings: {warnings}[/dim]\n"
                f"[dim]Finished at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}[/dim]",
                title="Success",
                style="green"
            ))
        else:
            console.print(Panel.fit(
                f"[bold red]✗ Optimization Failed![/bold red]\n"
                f"[dim]Return code: {process.returncode}[/dim]\n"
                f"[dim]Check the logs above for details[/dim]",
                title="Error",
                style="red"
            ))
            
            # Show last few lines for context
            if lines_buffer:
                console.print("\n[bold]Last few output lines:[/bold]")
                for line in lines_buffer[-5:]:
                    console.print(f"  {line}")

if __name__ == "__main__":
    # Parse command line arguments (everything after the script name goes to the optimizer)
    args = sys.argv[1:]
    
    if not args or "--help" in args or "-h" in args:
        console.print("""
[bold cyan]MAAS Optimizer Monitor[/bold cyan]

Usage: python monitor_optimize.py [optimizer arguments]

Example:
    python monitor_optimize.py --dataset HumanEval --round 1 --sample 1 --exec_model_name "gpt-4o-mini"

This script provides enhanced monitoring for the MAAS optimization process.
        """)
    else:
        try:
            run_optimizer_with_monitoring(args)
        except KeyboardInterrupt:
            console.print("\n[yellow]Process interrupted by user[/yellow]")
        except Exception as e:
            console.print(f"\n[red]Error: {e}[/red]")