import torch

# Load checkpoint
path = '/home/davoud/MaAS/maas/ext/maas/scripts/optimized/HumanEval/train/round_5/HumanEval_controller_sample4.pth'
xx = torch.load(path, map_location='cpu')
# Print all weight stats
[print(f"{k}: shape={v.shape}, min={v.min().item():.4f}, max={v.max().item():.4f}, mean={v.mean().item():.4f}") for k,v in xx.items() if isinstance(v, torch.Tensor)]
import pdb; pdb.set_trace()
# Operations: 0=Generate, 1=GenerateCoT, 2=MultiGenerateCoT, 3=ScEnsemble, 4=Test, 5=SelfRefine, 6=EarlyStop

# Choose which operation to activate (0-6)
active_operation = 0  # Change this to test different operations

print(f"Creating checkpoint with ONLY operation {active_operation} active")

# Create single-operation checkpoint
single_op_ckpt = {}

for k, v in xx.items():
    if isinstance(v, torch.Tensor):
        # Operation bias (7 operations) - only one is active
        if len(v.shape) == 1 and v.shape[0] == 7:
            biases = torch.zeros(7, dtype=v.dtype)
            biases[active_operation] = 10.0  # Very high bias for selected operation
            single_op_ckpt[k] = biases
            print(f"  {k}: All zeros except operation {active_operation} = 10.0")
        # All other weights - zeros
        else:
            single_op_ckpt[k] = torch.zeros_like(v)

# Save
output_path = path.replace('_sample4.pth', f'_SINGLE_OP_{active_operation}.pth')
torch.save(single_op_ckpt, output_path)
print(f"\nSaved: {output_path}")
print("All weights overwritten (non-tensors excluded)")
# Save
output_path = path.replace('_sample4.pth', f'_SINGLE_OP_{active_operation}.pth')
torch.save(single_op_ckpt, output_path)
print(f"\nSaved: {output_path}")

import pdb; pdb.set_trace()

import torch

# Load checkpoint
path = '/home/davoud/MaAS/maas/ext/maas/scripts/optimized/HumanEval/train/round_5/HumanEval_controller_sample4.pth'
xx = torch.load(path, map_location='cpu')

print("Creating WORST-CASE checkpoint for HumanEval...")

# Operations
OPERATIONS = ["Generate", "GenerateCoT", "MultiGenerateCoT", "ScEnsemble", "Test", "SelfRefine", "EarlyStop"]

# Create worst-case checkpoint
worst_ckpt = {}

for k, v in xx.items():
    if isinstance(v, torch.Tensor):
        shape = v.shape
        
        # Operation bias vector (7 operations)
        if len(shape) == 1 and shape[0] == 7:
            print(f"\n💀 {k}: Setting worst-case biases")
            worst_ckpt[k] = torch.tensor([
                2.0,   # Generate (HIGH - bad)
                0.5,   # GenerateCoT
                -2.0,  # MultiGenerateCoT (LOW - avoid!)
                -0.5,  # ScEnsemble
                -1.5,  # Test (LOW - skip validation!)
                -1.0,  # SelfRefine (LOW - avoid correction)
                1.5    # EarlyStop (HIGH - exit early)
            ], dtype=v.dtype, device=v.device)
            
        # Operation weight matrix (7 x N)
        elif len(shape) == 2 and shape[0] == 7:
            print(f"💀 {k}: Setting worst-case weights")
            std = (2.0 / sum(shape)) ** 0.5
            weights = torch.randn_like(v) * std
            scales = torch.tensor([1.5, 1.0, 0.5, 0.7, 0.5, 0.6, 1.2], dtype=v.dtype, device=v.device).view(-1, 1)
            worst_ckpt[k] = weights * scales
            
        # Other tensors
        else:
            worst_ckpt[k] = torch.randn_like(v) * 0.02
            
    else:
        worst_ckpt[k] = v

# Save
worst_path = path.replace('_sample4.pth', '_WORST_CASE.pth')
torch.save(worst_ckpt, worst_path)

print(f"\n✅ Saved to: {worst_path}")
print("\nWorst-case strategy:")
print("  - Generate simple solutions (no reasoning)")
print("  - Skip testing")
print("  - Exit immediately")
print("  - Avoid diversity and refinement")

import pdb; pdb.set_trace()




import torch
import torch.nn.functional as F

# Load the trained checkpoint
path = '/home/davoud/MaAS/maas/ext/maas/scripts/optimized/HumanEval/train/round_5/HumanEval_controller_sample4.pth'
xx = torch.load(path, map_location='cpu')

print("="*80)
print("CREATING OPTIMAL CHECKPOINT WITH EXACT SAME DIMENSIONS")
print("="*80)

# Operations for HumanEval
OPERATIONS = [
    "Generate",           # 0
    "GenerateCoT",        # 1
    "MultiGenerateCoT",   # 2
    "ScEnsemble",         # 3
    "Test",               # 4
    "SelfRefine",         # 5
    "EarlyStop"           # 6
]

print("""
🎯 Optimal Strategy for HumanEval:
   1. MultiGenerateCoT (bias=+1.5) - Generate diverse solutions
   2. Test (bias=+1.2)              - Validate rigorously
   3. SelfRefine (bias=+1.0)        - Fix failures
   4. ScEnsemble (bias=+0.5)        - Select best
   5. EarlyStop (bias=+0.3)         - Exit when done
   6. GenerateCoT (bias=0.0)        - Baseline
   7. Generate (bias=-1.0)          - Rarely use
""")

# Create optimal checkpoint - PRESERVE EXACT DIMENSIONS
optimal_ckpt = {}

for k, v in xx.items():
    if isinstance(v, torch.Tensor):
        shape = v.shape
        dtype = v.dtype
        device = v.device
        
        # Check if this is operation bias vector (7 operations)
        if len(shape) == 1 and shape[0] == 7:
            # OPERATION BIAS VECTOR - Most important!
            print(f"\n🎯 {k}: OPERATION BIAS VECTOR")
            optimal_biases = torch.tensor([
                -1.0,  # Generate
                0.0,   # GenerateCoT
                1.5,   # MultiGenerateCoT (HIGHEST)
                0.5,   # ScEnsemble
                1.2,   # Test (VERY HIGH)
                1.0,   # SelfRefine (HIGH)
                0.3    # EarlyStop
            ], dtype=dtype, device=device)
            
            optimal_ckpt[k] = optimal_biases
            
        # Check if this is operation weight matrix (7 operations output)
        elif len(shape) == 2 and shape[0] == 7:
            print(f"\n🎯 {k}: OPERATION WEIGHT MATRIX ({shape})")
            out_dim, in_dim = shape
            
            # Xavier initialization with operation priority scaling
            std = (2.0 / (in_dim + out_dim)) ** 0.5
            optimal_weight = torch.randn(out_dim, in_dim, dtype=dtype, device=device) * std
            
            operation_scales = torch.tensor([
                0.7, 1.0, 1.5, 1.1, 1.4, 1.3, 1.0
            ], dtype=dtype, device=device).view(-1, 1)
            
            optimal_ckpt[k] = optimal_weight * operation_scales
            
        # Regular weight matrix
        elif len(shape) == 2:
            out_dim, in_dim = shape
            std = (2.0 / (in_dim + out_dim)) ** 0.5
            optimal_ckpt[k] = torch.randn(out_dim, in_dim, dtype=dtype, device=device) * std
            
        # Regular bias vector
        elif len(shape) == 1:
            optimal_ckpt[k] = torch.zeros(shape[0], dtype=dtype, device=device)
            
        # Any other tensor shape
        else:
            optimal_ckpt[k] = torch.randn_like(v) * 0.02
        
        # Verify dimensions match
        assert optimal_ckpt[k].shape == v.shape, f"Shape mismatch for {k}!"
        assert optimal_ckpt[k].dtype == v.dtype, f"Dtype mismatch for {k}!"
        
    else:
        # Non-tensor: copy exactly
        optimal_ckpt[k] = v

# Final verification
print("\n" + "="*80)
print("DIMENSION VERIFICATION")
print("="*80)

for k in xx.keys():
    if isinstance(xx[k], torch.Tensor):
        assert xx[k].shape == optimal_ckpt[k].shape
        assert xx[k].dtype == optimal_ckpt[k].dtype
        print(f"✅ {k}: {xx[k].shape} ({xx[k].dtype})")

# Save the optimal checkpoint
optimal_path = path.replace('_sample4.pth', '_OPTIMAL_INFERRED.pth')
torch.save(optimal_ckpt, optimal_path)

print(f"\n{'='*80}")
print(f"✅ Saved to: {optimal_path}")
print(f"{'='*80}")

# Show weight comparison
print("\nWEIGHT COMPARISON:")
for k in xx.keys():
    if isinstance(xx[k], torch.Tensor):
        print(f"{k}: Original mean={xx[k].mean():.4f}, Optimal mean={optimal_ckpt[k].mean():.4f}")

print("\n✅ DONE! Dimensions guaranteed identical!")

import pdb; pdb.set_trace()















import torch
path = '/home/davoud/MaAS/maas/ext/maas/scripts/optimized/HumanEval/train/round_5/HumanEval_controller_sample4.pth'
# Load original
xx = torch.load(path, map_location='cpu')
# Print all weight stats
[print(f"{k}: shape={v.shape}, min={v.min().item():.4f}, max={v.max().item():.4f}, mean={v.mean().item():.4f}") for k,v in xx.items() if isinstance(v, torch.Tensor)]
# Create random version
new_ckpt = {k: torch.randn_like(v) if isinstance(v, torch.Tensor) else v 
            for k, v in xx.items()}

# Verify
print("Original vs Random:")
for k in list(xx.keys())[:3]:  # Check first 3
    if isinstance(xx[k], torch.Tensor):
        print(f"{k}:")
        print(f"  Original: shape={xx[k].shape}, mean={xx[k].mean():.3f}")
        print(f"  Random:   shape={new_ckpt[k].shape}, mean={new_ckpt[k].mean():.3f}")

# Save

torch.save(new_ckpt, 'random_checkpoint.pth')
print("\n✅ Saved to random_checkpoint.pth")